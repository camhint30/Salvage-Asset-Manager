-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema db
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema db
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `db` DEFAULT CHARACTER SET utf8 ;
USE `db` ;

-- -----------------------------------------------------
-- Table `db`.`Item`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db`.`Item` (
  `itemID` INT(255) NOT NULL AUTO_INCREMENT,
  `itemSerialNumber` VARCHAR(45) NULL,
  `itemMake` VARCHAR(45) NULL,
  `itemModel` VARCHAR(45) NULL,
  `itemNotes` VARCHAR(45) NULL,
  `itemLocation` VARCHAR(45) NULL,
  `itemCapitalAsset` TINYINT NOT NULL DEFAULT 0,
  `itemType` VARCHAR(45) NULL,
  PRIMARY KEY (`itemID`))
ENGINE = InnoDB;

CREATE UNIQUE INDEX `itemID_UNIQUE` ON `db`.`Item` (`itemID` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `db`.`Computer`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db`.`Computer` (
  `computerID` INT(255) NOT NULL,
  `serviceTag` VARCHAR(12) NULL,
  `componentMissing` VARCHAR(45) NULL,
  `computerType` VARCHAR(45) NULL,
  PRIMARY KEY (`computerID`),
  CONSTRAINT `computerID`
    FOREIGN KEY (`computerID`)
    REFERENCES `db`.`Item` (`itemID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db`.`Keyboard`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db`.`Keyboard` (
  `keyboardID` INT(255) NOT NULL,
  `keyboardQuantity` INT(255) NOT NULL DEFAULT 0,
  `keyboardMake` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`keyboardID`),
  CONSTRAINT `keyboardID`
    FOREIGN KEY (`keyboardID`)
    REFERENCES `db`.`Item` (`itemID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE UNIQUE INDEX `keyboardMake_UNIQUE` ON `db`.`Keyboard` (`keyboardMake` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `db`.`Mouse`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db`.`Mouse` (
  `mouseID` INT(255) NOT NULL,
  `mouseQuantity` INT(255) NOT NULL DEFAULT 0,
  `itemMake` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`mouseID`),
  CONSTRAINT `mouseID`
    FOREIGN KEY (`mouseID`)
    REFERENCES `db`.`Item` (`itemID`)
    ON DELETE CASCADE
    ON UPDATE CASCADE)
ENGINE = InnoDB;

CREATE UNIQUE INDEX `itemMake_UNIQUE` ON `db`.`Mouse` (`itemMake` ASC) VISIBLE;


-- -----------------------------------------------------
-- Table `db`.`Events`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db`.`Events` (
  `eventID` INT(255) NOT NULL,
  `eventDate` VARCHAR(20) NULL,
  `eventAction` VARCHAR(100) NULL,
  `eventUsername` VARCHAR(45) NULL,
  PRIMARY KEY (`eventID`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `db`.`User`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `db`.`User` (
  `userUsername` VARCHAR(25) NOT NULL,
  `userFirstName` VARCHAR(45) NOT NULL,
  `userLastName` VARCHAR(45) NOT NULL,
  `userPassword` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`userUsername`))
ENGINE = InnoDB;

CREATE UNIQUE INDEX `userPassword_UNIQUE` ON `db`.`User` (`userPassword` ASC);

CREATE UNIQUE INDEX `userUsername_UNIQUE` ON `db`.`User` (`userUsername` ASC);


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
