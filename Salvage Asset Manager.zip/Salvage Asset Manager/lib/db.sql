-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2019 at 04:17 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `computer`
--

CREATE TABLE `computer` (
  `computerID` int(255) NOT NULL,
  `serviceTag` varchar(12) DEFAULT NULL,
  `componentMissing` varchar(45) DEFAULT NULL,
  `computerType` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `eventID` int(255) NOT NULL,
  `eventDate` varchar(20) DEFAULT NULL,
  `eventAction` varchar(100) DEFAULT NULL,
  `eventUsername` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events`
--

INSERT INTO `events` (`eventID`, `eventDate`, `eventAction`, `eventUsername`) VALUES
(1, '04-23-2019 13:42:20', 'Created Desktop: Make: Dell / Model: in5 / Service Tag: 123', 'skarali'),
(2, '04-23-2019 13:43:08', 'Deleted: Desktop: Make: Dell / Model: in5 / Service Tag: 123', 'skarali'),
(3, '04-23-2019 13:45:17', 'Created Desktop: Make: HP / Model: v6.0 / Service Tag: 12345', 'skarali'),
(4, '04-23-2019 13:45:47', 'Created Laptop: Make: Dell / Model: n2.0 / Service Tag: 2222', 'skarali'),
(5, '04-23-2019 14:15:36', 'Created Laptop: Make: 1234 / Model: 1234 / Service Tag: 321', 'skarali'),
(6, '04-23-2019 14:36:06', 'Created Laptop: Make: 4444 / Model: 4444 / Service Tag: 4444', 'skarali'),
(7, '04-23-2019 15:45:19', 'Deleted: Laptop: Make: Dell / Model: n2.0 / Service Tag: 2222', 'skarali'),
(8, '04-23-2019 15:45:31', 'Deleted: Laptop: Make: 4444 / Model: 4444 / Service Tag: 4444', 'skarali'),
(9, '04-23-2019 19:42:54', 'Deleted: Desktop: Make: HP / Model: v6.0 / Service Tag: 12345', 'skarali'),
(10, '04-23-2019 19:43:05', 'Deleted: Laptop: Make: 1234 / Model: 1234 / Service Tag: 321', 'skarali');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `itemID` int(255) NOT NULL,
  `itemSerialNumber` varchar(45) DEFAULT NULL,
  `itemMake` varchar(45) DEFAULT NULL,
  `itemModel` varchar(45) DEFAULT NULL,
  `itemNotes` varchar(45) DEFAULT NULL,
  `itemLocation` varchar(45) DEFAULT NULL,
  `itemCapitalAsset` tinyint(4) NOT NULL DEFAULT '0',
  `itemType` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`itemID`, `itemSerialNumber`, `itemMake`, `itemModel`, `itemNotes`, `itemLocation`, `itemCapitalAsset`, `itemType`) VALUES
(2, NULL, 'HP', 'v6.0', 'NONE', '3', 0, 'Desktop');

-- --------------------------------------------------------

--
-- Table structure for table `keyboard`
--

CREATE TABLE `keyboard` (
  `keyboardID` int(255) NOT NULL,
  `keyboardQuantity` int(255) NOT NULL DEFAULT '0',
  `keyboardMake` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `mouse`
--

CREATE TABLE `mouse` (
  `mouseID` int(255) NOT NULL,
  `mouseQuantity` int(255) NOT NULL DEFAULT '0',
  `itemMake` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `userUsername` varchar(25) NOT NULL,
  `userFirstName` varchar(45) NOT NULL,
  `userLastName` varchar(45) NOT NULL,
  `userPassword` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`userUsername`, `userFirstName`, `userLastName`, `userPassword`) VALUES
('skarali', 'sameer', 'karali', '11'),
('test', 'te', 'st', '10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `computer`
--
ALTER TABLE `computer`
  ADD PRIMARY KEY (`computerID`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`eventID`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`itemID`);

--
-- Indexes for table `keyboard`
--
ALTER TABLE `keyboard`
  ADD PRIMARY KEY (`keyboardID`);

--
-- Indexes for table `mouse`
--
ALTER TABLE `mouse`
  ADD PRIMARY KEY (`mouseID`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`userUsername`),
  ADD UNIQUE KEY `userPassword_UNIQUE` (`userPassword`),
  ADD UNIQUE KEY `userUsername_UNIQUE` (`userUsername`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `itemID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `computer`
--
ALTER TABLE `computer`
  ADD CONSTRAINT `computerID` FOREIGN KEY (`computerID`) REFERENCES `item` (`itemID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `keyboard`
--
ALTER TABLE `keyboard`
  ADD CONSTRAINT `keyboardID` FOREIGN KEY (`keyboardID`) REFERENCES `item` (`itemID`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `mouse`
--
ALTER TABLE `mouse`
  ADD CONSTRAINT `mouseID` FOREIGN KEY (`mouseID`) REFERENCES `item` (`itemID`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
