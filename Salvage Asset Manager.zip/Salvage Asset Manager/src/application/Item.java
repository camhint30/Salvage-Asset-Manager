package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import javafx.beans.property.*;

/*
 * An abstract class that defines each child of Item
 */
public class Item {

	SimpleStringProperty type, make, model, notes, location, serialNumber;
	SimpleStringProperty serviceTag;
	SimpleIntegerProperty capAsset;
	
	
	public Item(String itemSerialNumber, String itemMake, String itemModel, String itemNotes, 
			String itemLocation, String itemType, int itemCapitalAsset) {
		super();
		this.serialNumber = new SimpleStringProperty(itemSerialNumber);
		this.serviceTag = new SimpleStringProperty();
		this.type = new SimpleStringProperty(itemType);
		this.make = new SimpleStringProperty(itemMake);
		this.model = new SimpleStringProperty(itemModel);
		this.notes = new SimpleStringProperty(itemNotes);
		this.location = new SimpleStringProperty(itemLocation);
		this.capAsset = new SimpleIntegerProperty(itemCapitalAsset);

	}
	public Item(String computerServiceTag, String itemMake, String itemModel, String itemNotes, 
			String itemLocation,int itemCapitalAsset, String itemType) {
		super();
		this.serviceTag = new SimpleStringProperty(computerServiceTag);
		this.serialNumber = new SimpleStringProperty();
		this.type = new SimpleStringProperty(itemType);
		this.make = new SimpleStringProperty(itemMake);
		this.model = new SimpleStringProperty(itemModel);
		this.notes = new SimpleStringProperty(itemNotes);
		this.location = new SimpleStringProperty(itemLocation);

	}
		public Item() {
		// TODO Auto-generated constructor stub
	}
	public String getItemType() {	
	
		return type.get();
	}
	public String getServiceTag() {
		if(serviceTag.equals(null))
				return "------";
		return serviceTag.get();
	}
	
	public void setServiceTag(String compServiceTag) {
		serviceTag.set(compServiceTag);
	}
	public void setItemType(String itemType) {
		type.set(itemType);
	}
	public String getItemMake() {
		return make.get();
	}
	public void setItemMake(String itemMake) {
		make.set(itemMake);
	}
	public String getItemModel() {
		return model.get();
	}
	public void setItemModel(String itemModel) {
		model.set(itemModel);
	}
	public String getItemNotes() {
		return notes.get();
	}
	public void setItemNotes(String itemNotes) {
		notes.set(itemNotes);
	}
	public String getItemLocation() {
		return location.get();
	}
	public void setItemLocation(String itemLocation) {
		location.set(itemLocation);
	}
	public String getItemSerialNumber() {
		return serialNumber.get();
	}
	public void setItemSerialNumber(String serialNum) {
		serialNumber.set(serialNum);
	}
	public int getItemIsCapitalAsset() {
		return capAsset.get();
	}
	public void setItemIsCapitalAsset(int itemCapitalAsset) {
		capAsset.set(itemCapitalAsset);
	}
	@Override
	public String toString() {
		return "Item [itemType=" + type + ", serviceTag="+ serviceTag + ", itemMake=" + make + ", itemModel=" + model + ", itemNotes="
				+ notes + ", itemLocation=" + location + ", itemSerialNumber=" + serialNumber
				+ ", itemIsCapitalAsset=" + capAsset + "]";
	}
	
	
	
}
