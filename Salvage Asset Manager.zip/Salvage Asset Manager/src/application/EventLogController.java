package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.sql.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.Scene;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextArea;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Hyperlink;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.layout.BorderPane;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

@SuppressWarnings("unused")
public class EventLogController implements Initializable{

	Stage primaryStage = new Stage();
	Parent parentRoot;
	
	@FXML
	Button homepageButton, quickEditButton, createItemButton, eventLogButton;
	
	static String user;
	String userAction;
	static Date date;
	
	@FXML
	TextArea eventLogTA;
	
	@FXML
	Button exportBtn,copyToClipboardBtn;
	
	@SuppressWarnings("unused")
	private Hyperlink hlinkLogout ;
	static UserAccount userAcc;
	ObservableList<Event> eventList = FXCollections.observableArrayList(ItemCreationController.eList);
	
	static ArrayList<Event> eList = ItemCreationController.getEventList();
	
	/*
	 * A method for exporting the logs to a text file
	 */
	public void export(){
		
		System.out.println("export clicked");
		FileChooser fileChooser = new FileChooser();
		FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("TXT files (*.txt)", "*.txt");
		fileChooser.getExtensionFilters().add(extFilter);
		File file = fileChooser.showSaveDialog(primaryStage);
		System.out.println(file);
		try{
		FileWriter fw=new FileWriter(file);
		PrintWriter pw=new PrintWriter(fw);
		pw.println(eventLogTA.getText().toString());
		pw.flush();
		fw.close();
		pw.close();
		}catch(Exception e){
				e.printStackTrace();
		}
	}
	
	public EventLogController() {
		
	}
	
	/*
	 * The initialize displays all the events from the database
	 * (non-Javadoc)
	 * @see javafx.fxml.Initializable#initialize(java.net.URL, java.util.ResourceBundle)
	 */
	
	@Override
	public void initialize(URL location, ResourceBundle resources){

		try {
			updateEvents();
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	@FXML
	private void updateEvents() throws ClassNotFoundException, SQLException {
	
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
	
		String eventQuery = "SELECT * FROM Events";
		Statement eventStmt = con.createStatement();
		
		ResultSet eventRS = eventStmt.executeQuery(eventQuery);
		
		
		while(eventRS.next()) {
			Event e = new Event(eventRS.getInt("eventID"), eventRS.getString("eventUsername"), eventRS.getString("eventDate"), eventRS.getString("eventAction"));
			eventLogTA.appendText(e.toString());
		}
		
	}
	
	@FXML
	private void callHomepage() throws IOException {
		
		primaryStage = (Stage) homepageButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Home Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	/*************** Quick Edit Page ***************/
	// A call method to display the Quick Edit page
	@FXML
	private void callEditPage() throws IOException {
		
		primaryStage = (Stage) quickEditButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("QuickEdit.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Quick Edit Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	/*************** Item Creation Page ***************/
	// A call method to display the Create Item Page
	@FXML
	private void callCreatePage() throws IOException {
		primaryStage = (Stage) createItemButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("ItemCreation.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Item Creation Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	// A call method to display the Event Logs page
	@FXML
	private void callEventLogs() throws IOException {
		primaryStage = (Stage) eventLogButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("EventLog.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Event Logs");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	public void setEvent(ObservableList<Event> eventList) {

		this.eventList = eventList;
	}
	
	@FXML
	private void mouseHover() {
		if(homepageButton.isHover()) {
			homepageButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(createItemButton.isHover()) {
			createItemButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(quickEditButton.isHover()) {
			quickEditButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(eventLogButton.isHover()) {
			eventLogButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
	}
	
	@FXML
	private void logout() throws IOException {

		Alert alert = new Alert(AlertType.NONE, "Are you sure you want to log out?", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		if(alert.getResult().equals(ButtonType.OK)) {
			primaryStage = (Stage) homepageButton.getScene().getWindow();

			parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Login Page");
			primaryStage.show();
			if (primaryStage.isMaximized()) {
				primaryStage.setMaximized(false);
				primaryStage.setWidth(600);
				primaryStage.setHeight(400);
			}
			
		}
	}
	public void copyToClipBoard(){
		
		final Clipboard clipboard = Clipboard.getSystemClipboard();
        final ClipboardContent content = new ClipboardContent();
        content.putString(eventLogTA.getText());
        clipboard.setContent(content);
	}
}
