package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

// A class UserAccount of type account for user account creation
public class UserAccount extends Account {

	static String userEmail;
	String userPassword;
	
	public UserAccount() {
		
	}
	
	public UserAccount(String userEmail, String userPassword) {
		super(userEmail, userPassword);
		UserAccount.userEmail = userEmail;
		this.userPassword = userPassword;
	}

	public String getUserEmail() {
		return userEmail;
	}

	public void setUserEmail(String userEmail) {
		UserAccount.userEmail = userEmail;
	}

	public String getUserPassword() {
		return userPassword;
	}

	public void setUserPassword(String userPassword) {
		this.userPassword = userPassword;
	
	}

	@Override
	public String toString() {
		return "UserAccount [userEmail=" + userEmail + ", userPassword=" + userPassword + "]";
	}
	
	
	

}
