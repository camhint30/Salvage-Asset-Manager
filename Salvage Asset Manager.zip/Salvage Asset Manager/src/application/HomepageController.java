package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.*;
import java.net.*;
import java.sql.*;
import java.util.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class HomepageController implements Initializable {

	Stage primaryStage = new Stage();
	Parent parentRoot;

	@FXML
	Button loginButton, createItemButton, eventLogButton, homepageButton, quickEditButton, homeRefreshBtn, searchBtn,
			resetBtn;

	@FXML
	TableView<Computer> computerTable, allOneTable, laptopTable;

	@FXML
	TableView<Item> itemTable;

	@FXML
	TableColumn<Item, String> itemMakeCol, itemModelCol, itemCompCol, itemLocCol, itemTypeCol;

	@FXML
	TableColumn<Item, String> itemSerialNumCol, itemServiceTagCol;

	@FXML
	TableColumn<Computer, String> computerMakeCol, computerModelCol, computerCompCol, computerLocCol, allOneMakeCol,
			allOneModelCol, allOneCompCol, allOneLocCol, laptopMakeCol, laptopModelCol, laptopCompCol, laptopLocCol;

	@FXML
	TableColumn<Computer, String> computerServiceTagCol, allOneServiceTagCol, laptopServiceTagCol;

	@FXML
	TableView<Mouse> mouseTable;

	@FXML
	TableView<Keyboard> keyboardTable;

	@FXML
	TableColumn<Mouse, Integer> mouseQuantityCol;

	@FXML
	TableColumn<Mouse, String> mouseMakeCol;

	@FXML
	TableColumn<Keyboard, Integer> keyboardQuantityCol;

	@FXML
	TableColumn<Keyboard, String> keyboardMakeCol;

	@FXML
	TableView<Printer> printerTable;

	@FXML
	TableColumn<Printer, String> printerMakeCol, printerModelCol, printerNoteCol, printerLocCol;

	@FXML
	TableColumn<Printer, String> printerSerialNumCol;

	@FXML
	TextField itemSearchBar, desktopSearchBar, laptopSearchBar;

	@FXML
	static Computer c;

	@FXML
	static Item i;

	@FXML
	Tab allTab, desktopTab, laptopTab, allOneTab, mouseTab, keyboardTab, printerTab;

	public HomepageController() {
	}

	/*
	 * The initialize method runs as the page is loaded
	 * It cycles through the different items to load the tableviews from the database
	 * (non-Javadoc)
	 * @see javafx.fxml.Initializable#initialize(java.net.URL, java.util.ResourceBundle)
	 */
	@Override
	public void initialize(URL location, ResourceBundle resources) {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			retrieveItems();
			retrieveComputer();

			editItem();

			editComputer();
			retrieveMouse();
			retrieveKeyboard();
			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@FXML
	private void searchItem() {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			String itemQuery = "";
			Statement itemStmt = con.createStatement();
			ResultSet itemRS = null;

			Item item = new Item();
			Item compItem = new Item();
			Computer newComputer = null;
			/*
			 * Selecting from the database the items and displaying them in the tableview
			 */
			if (allTab.isSelected()) {
				itemQuery = "SELECT * FROM Item WHERE itemMake = '" + itemSearchBar.getText() + "' OR itemModel = '"
						+ itemSearchBar.getText() + "' OR itemSerialNumber ='" + itemSearchBar.getText()
						+ "' OR itemType = '" + itemSearchBar.getText() + "'";

				itemRS = itemStmt.executeQuery(itemQuery);

				while (itemRS.next()) {
					itemTable.getItems().clear();
					if ((itemRS.getString("itemType").equalsIgnoreCase("Desktop")
							|| itemRS.getString("itemType").equalsIgnoreCase("Laptop")
							|| itemRS.getString("itemType").equalsIgnoreCase("All-In-One")
							|| itemRS.getString("itemType").equalsIgnoreCase("Mouse")
							|| itemRS.getString("itemType").equalsIgnoreCase("Keyboard"))) {
						continue;

					} else {
						item = new Item(itemRS.getString("itemSerialNumber"), itemRS.getString("itemMake"),
								itemRS.getString("itemModel"), itemRS.getString("itemNotes"),
								itemRS.getString("itemLocation"), itemRS.getString("itemType"),
								itemRS.getInt("itemCapitalAsset"));

						itemSerialNumCol
								.setCellValueFactory(new PropertyValueFactory<Item, String>("itemSerialNumber"));
						itemServiceTagCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemServiceTag"));
						itemMakeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemMake"));
						itemModelCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemModel"));
						itemLocCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemLocation"));
						itemTypeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemType"));
						itemTable.getItems().add(item);
					}

				}
				itemRS.close();
				itemStmt.close();
				
				/*
				 * Selecting the items from the database and displaying them in the tableview
				 */

				String compQuery = "SELECT Item.itemMake, item.itemModel, item.itemLocation, item.itemType, item.itemCapitalAsset"
						+ ", computer.serviceTag, computer.computerType, computer.componentMissing" + " FROM Item "
						+ "JOIN Computer " + " WHERE Computer.computerID = Item.itemID AND (item.itemMake = '"
						+ itemSearchBar.getText() + "'" + " OR item.itemModel = '" + itemSearchBar.getText()
						+ "' OR item.itemType = '" + itemSearchBar.getText() + "' OR computer.serviceTag = '"
						+ itemSearchBar.getText() + "')";
				Statement compStmt = con.createStatement();
				ResultSet compRS = compStmt.executeQuery(compQuery);
				itemTable.getItems().clear();
				
				while (compRS.next()) {

					if (compRS.getString("computer.computerType").equalsIgnoreCase("Desktop")) {
						compItem = new Item(compRS.getString("computer.serviceTag"), compRS.getString("item.itemMake"),
								compRS.getString("item.itemModel"), compRS.getString("computer.componentMissing"),
								compRS.getString("item.itemLocation"), compRS.getInt("item.itemCapitalAsset"),
								compRS.getString("item.itemType"));
						
						itemServiceTagCol.setCellValueFactory(new PropertyValueFactory<Item, String>("serviceTag"));
						itemMakeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemMake"));
						itemModelCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemModel"));
						itemLocCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemLocation"));
						itemTypeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemType"));
						itemTable.getItems().add(compItem);
					}
					if (compRS.getString("item.itemType").equalsIgnoreCase("Laptop")) {
						compItem = new Item(compRS.getString("computer.serviceTag"), compRS.getString("item.itemMake"),
								compRS.getString("item.itemModel"), compRS.getString("computer.componentMissing"),
								compRS.getString("item.itemLocation"), compRS.getInt("item.itemCapitalAsset"),
								compRS.getString("item.itemType"));

						itemServiceTagCol.setCellValueFactory(new PropertyValueFactory<Item, String>("serviceTag"));
						itemMakeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemMake"));
						itemModelCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemModel"));
						itemLocCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemLocation"));
						itemTypeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemType"));
						itemTable.getItems().add(compItem);
					}
					if (compRS.getString("item.itemType").equalsIgnoreCase("All-In-One")) {
						compItem = new Item(compRS.getString("computer.serviceTag"), compRS.getString("item.itemMake"),
								compRS.getString("item.itemModel"), compRS.getString("computer.componentMissing"),
								compRS.getString("item.itemLocation"), compRS.getInt("item.itemCapitalAsset"),
								compRS.getString("item.itemType"));

						itemServiceTagCol.setCellValueFactory(new PropertyValueFactory<Item, String>("serviceTag"));
						itemMakeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemMake"));
						itemModelCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemModel"));
						itemLocCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemLocation"));
						itemTypeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemType"));
						itemTable.getItems().add(compItem);
					}
				}
			}
			if (desktopTab.isSelected()) {
				String desktopQuery = "SELECT computer.serviceTag, item.itemCapitalAsset, computer.componentMissing, computer.computerID, item.itemMake,"
						+ "item.itemModel, computer.computerType, item.itemLocation FROM Computer Join Item WHERE computer.computerID = item.itemID AND computer.computerType ="
						+ "'Desktop' AND item.itemMake = '" + desktopSearchBar.getText() + "' OR item.itemType = '"
						+ desktopSearchBar.getText() + "' OR item.itemModel = '" + desktopSearchBar.getText()
						+ "' OR computer.serviceTag = '" + desktopSearchBar.getText() + "'";
				Statement desktopStmt = con.createStatement();
				ResultSet desktopRS = desktopStmt.executeQuery(desktopQuery);

				while (desktopRS.next()) {

					newComputer = new Desktop(desktopRS.getString("computer.serviceTag"),
							desktopRS.getString("computer.componentMissing"), desktopRS.getString("item.itemMake"),
							desktopRS.getString("item.itemModel"), desktopRS.getString("item.itemLocation"),
							desktopRS.getString("computer.computerType"), desktopRS.getInt("item.itemCapitalAsset"));

					computerServiceTagCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("serviceTag"));
					computerMakeCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerMake"));
					computerModelCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerModel"));
					computerLocCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerLocation"));
					computerCompCol.setCellValueFactory(
							new PropertyValueFactory<Computer, String>("computerComponentMissing"));
					computerTable.getItems().add(newComputer);
				}

			}
			if (laptopTab.isSelected()) {
				laptopTable.getItems().clear();
				String laptopQuery = "SELECT computer.serviceTag, item.itemCapitalAsset, computer.componentMissing, computer.computerID, item.itemMake,"
						+ "item.itemModel, computer.computerType, item.itemLocation FROM Computer Join Item WHERE computer.computerID = item.itemID AND computer.computerType ="
						+ "'Laptop' AND item.itemMake = '" + searchBtn.getText() + "' OR item.itemType = '"
						+ searchBtn.getText() + "' OR item.itemModel = '" + searchBtn.getText()
						+ "' OR computer.serviceTag = '" + searchBtn.getText() + "'";
				Statement laptopStmt = con.createStatement();
				ResultSet laptopRS = laptopStmt.executeQuery(laptopQuery);

				while (laptopRS.next()) {

					newComputer = new Desktop(laptopRS.getString("computer.serviceTag"),
							laptopRS.getString("computer.componentMissing"), laptopRS.getString("item.itemMake"),
							laptopRS.getString("item.itemModel"), laptopRS.getString("item.itemLocation"),
							laptopRS.getString("computer.computerType"), laptopRS.getInt("item.itemCapitalAsset"));

					laptopServiceTagCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("serviceTag"));
					laptopMakeCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerMake"));
					laptopModelCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerModel"));
					laptopLocCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerLocation"));
					laptopCompCol.setCellValueFactory(
							new PropertyValueFactory<Computer, String>("computerComponentMissing"));
					laptopTable.getItems().add(newComputer);
				}

			}
			if (allOneTab.isSelected()) {
				allOneTable.getItems().clear();
				String allOneQuery = "SELECT computer.serviceTag, item.itemCapitalAsset, computer.componentMissing, computer.computerID, item.itemMake,"
						+ "item.itemModel, computer.computerType, item.itemLocation FROM Computer Join Item WHERE computer.computerID = item.itemID AND computer.computerType ="
						+ "'All-In-One' AND item.itemMake = '" + searchBtn.getText() + "' OR item.itemType = '"
						+ searchBtn.getText() + "' OR item.itemModel = '" + searchBtn.getText()
						+ "' OR computer.serviceTag = '" + searchBtn.getText() + "'";
				Statement allOneStmt = con.createStatement();
				ResultSet allOneRS = allOneStmt.executeQuery(allOneQuery);

				while (allOneRS.next()) {

					newComputer = new AllOnePC(allOneRS.getString("computer.serviceTag"),
							allOneRS.getString("computer.componentMissing"), allOneRS.getString("item.itemMake"),
							allOneRS.getString("item.itemModel"), allOneRS.getString("item.itemLocation"),
							allOneRS.getString("computer.computerType"), allOneRS.getInt("item.itemCapitalAsset"));

					allOneServiceTagCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("serviceTag"));
					allOneMakeCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerMake"));
					allOneModelCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerModel"));
					allOneLocCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerLocation"));
					allOneCompCol.setCellValueFactory(
							new PropertyValueFactory<Computer, String>("computerComponentMissing"));
					allOneTable.getItems().add(newComputer);
				}

			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * When the reset button is selected, this method clears all tables and resets the tables from the database
	 */
	@FXML
	private void resetTable() {
		try {
			itemTable.getItems().clear();
			computerTable.getItems().clear();
			laptopTable.getItems().clear();
			allOneTable.getItems().clear();
			printerTable.getItems().clear();
			keyboardTable.getItems().clear();
			mouseTable.getItems().clear();
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			retrieveItems();
			retrieveComputer();

			editItem();

			editComputer();
			retrieveMouse();
			retrieveKeyboard();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * The method for double-clicking on an item
	 */
	@FXML
	private void getComputerEdit() throws IOException {
		primaryStage = (Stage) quickEditButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("EditPC.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Edit Computer Page");
		primaryStage.show();

		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	@FXML
	private void getEditItem() throws IOException {
		primaryStage = (Stage) homepageButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("EditItem.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Edit Item Page");
		primaryStage.show();

		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	@FXML
	private void editComputer() {

		/*
		 * This method allows the double-click action on a tableview item to be selected and displayed on the edit page
		 */
		computerTable.setRowFactory(tv -> {
			TableRow<Computer> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 2 && (!row.isEmpty())) {
					c = row.getItem();
					QuickEditController.comp = c;
					String serviceTag = c.getServiceTag();
					try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root",
								"password");

						String query = "SELECT Item.itemMake, item.itemModel, item.itemLocation, item.itemType, item.itemCapitalAsset,"
								+ "Computer.serviceTag, computer.componentMissing FROM Item JOIN Computer WHERE Computer.computerID"
								+ " = Item.itemID AND computer.serviceTag= '" + serviceTag + "'";

						Statement stmnt = con.createStatement();

						ResultSet editRS = stmnt.executeQuery(query);
						while (editRS.next()) {
							if (stmnt.getResultSet().getString("Item.itemType").equals("Laptop")) {
								c = new Laptop(editRS.getString("Computer.serviceTag"),
										editRS.getString("Computer.componentMissing"),
										editRS.getString("Item.itemMake"), editRS.getString("Item.itemModel"),
										editRS.getString("Item.itemLocation"), editRS.getString("Item.itemType"),
										editRS.getInt("Item.itemCapitalAsset"));
							}
							QuickEditController.comp = c;
						}

						getComputerEdit();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});

			return row;
		});
		
		/*
		 * This method allows the double-click action on a tableview item to be selected and displayed on the edit page
		 */
		
		laptopTable.setRowFactory(tv -> {
			TableRow<Computer> row = new TableRow<>();
			row.setOnMouseClicked(event -> {
				if (event.getClickCount() == 2 && (!row.isEmpty())) {
					c = row.getItem();
					QuickEditController.comp = c;
					String serviceTag = c.getServiceTag();
					try {
						Class.forName("com.mysql.jdbc.Driver");
						Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root",
								"password");

						String query = "SELECT Item.itemMake, item.itemModel, item.itemLocation, item.itemType, item.itemCapitalAsset,"
								+ "Computer.serviceTag, computer.componentMissing FROM Item JOIN Computer WHERE Computer.computerID"
								+ " = Item.itemID AND computer.serviceTag= '" + serviceTag + "'";

						Statement stmnt = con.createStatement();

						ResultSet editRS = stmnt.executeQuery(query);
						while (editRS.next()) {
							if (stmnt.getResultSet().getString("Item.itemType").equals("Laptop")) {
								c = new Laptop(editRS.getString("Computer.serviceTag"),
										editRS.getString("Computer.componentMissing"),
										editRS.getString("Item.itemMake"), editRS.getString("Item.itemModel"),
										editRS.getString("Item.itemLocation"), editRS.getString("Item.itemType"),
										editRS.getInt("Item.itemCapitalAsset"));
							}
							QuickEditController.comp = c;
						}

						getComputerEdit();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			});

			return row;
		});
	}

	@FXML
	private void editItem() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			/*
			 * This method allows the double-click action on a tableview item to be selected and displayed on the edit page
			 */
			
			itemTable.setRowFactory(tv -> {
				TableRow<Item> row = new TableRow<>();
				row.setOnMouseClicked(event -> {
					if (event.getClickCount() == 2 && (!row.isEmpty())) {
						i = row.getItem();
						if (i.getItemType().equals("Desktop") || i.getItemType().equals("Laptop")
								|| i.getItemType().equals("All-In-One")) {
							try {
								String compQuery = "Select Item.itemMake, item.itemModel, item.itemType, item.itemLocation, item.itemCapitalAsset,"
										+ "Computer.servicetag, Computer.computerType, Computer.componentMissing From Item Join Computer WHERE computer.computerID = item.itemID"
										+ " AND Computer.serviceTag = '" + i.getServiceTag() + "'";
								Statement compStmt = con.createStatement();
								ResultSet compRS = compStmt.executeQuery(compQuery);
								while (compRS.next()) {
									Computer computer = null;
									if(compRS.getString("item.itemType").equalsIgnoreCase("Desktop")) {
										computer = new Desktop(compRS.getString("Computer.serviceTag"),
												compRS.getString("computer.componentMissing"),
												compRS.getString("item.itemMake"), compRS.getString("item.itemModel"),
												compRS.getString("item.itemLocation"), compRS.getString("item.itemType"),
												compRS.getInt("item.itemCapitalAsset"));

									}
									if(compRS.getString("item.itemType").equalsIgnoreCase("Laptop")) {
										computer = new Laptop(compRS.getString("Computer.serviceTag"),
												compRS.getString("computer.componentMissing"),
												compRS.getString("item.itemMake"), compRS.getString("item.itemModel"),
												compRS.getString("item.itemLocation"), compRS.getString("item.itemType"),
												compRS.getInt("item.itemCapitalAsset"));
									}
									if(compRS.getString("item.itemType").equalsIgnoreCase("All-In-One")) {
										computer = new AllOnePC(compRS.getString("Computer.serviceTag"),
												compRS.getString("computer.componentMissing"),
												compRS.getString("item.itemMake"), compRS.getString("item.itemModel"),
												compRS.getString("item.itemLocation"), compRS.getString("item.itemType"),
												compRS.getInt("item.itemCapitalAsset"));
									}
									QuickEditController.comp = computer;
									
								}
								getComputerEdit();
							} catch (SQLException e) {
								e.printStackTrace();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							} 
						}
						else  {
							
							String itemQuery = "SELECT itemCapitalAsset, itemMake, itemSerialNumber, itemModel, itemLocation, itemNotes, itemType FROM Item"
									+ " WHERE itemSerialNumber = '" + i.getItemSerialNumber() + "'";
							try {
								Statement itemStmt = con.createStatement();
								ResultSet itemRS = itemStmt.executeQuery(itemQuery);

								while (itemRS.next()) {
									QuickEditController.item = new Item(itemRS.getString("item.itemSerialNumber"),
											itemRS.getString("item.itemMake"), itemRS.getString("item.itemModel"),
											itemRS.getString("item.itemNotes"), itemRS.getString("item.itemLocation"),
											itemRS.getString("item.itemType"), itemRS.getInt("item.itemCapitalAsset"));
									
								}
								

								getEditItem();
							} catch (SQLException e) {
								e.printStackTrace();
							} catch (IOException e) {
								e.printStackTrace();
							}

						}
					}
				});

				return row;
			});
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * This method allows the double-click action on a tableview item to be selected and displayed on the edit page
	 */
	@FXML
	private void retrieveComputer() throws SQLException {

		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

		String itemQuery = "SELECT item.itemMake, item.itemModel, item.itemLocation, item.itemCapitalAsset,"
				+ "computer.computerType, computer.serviceTag, computer.componentMissing" + " FROM item "
				+ " JOIN computer " + "ON item.itemID = computer.computerID";

		Statement itemStmt = con.createStatement();
		ResultSet itemRS = itemStmt.executeQuery(itemQuery);
		Computer comp = new Computer();

		while (itemRS.next()) {
			if (itemRS.getString("computerType").equalsIgnoreCase("Desktop")) {
				comp = new Desktop(itemRS.getString("computer.serviceTag"),
						itemRS.getString("computer.componentMissing"), itemRS.getString("item.itemMake"),
						itemRS.getString("item.itemModel"), itemRS.getString("item.itemLocation"),
						itemRS.getString("computer.computerType"), itemRS.getInt("itemCapitalAsset"));

				computerServiceTagCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("serviceTag"));
				computerMakeCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerMake"));
				computerModelCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerModel"));
				computerLocCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerLocation"));
				computerCompCol
						.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerComponentMissing"));
				computerTable.getItems().add(comp);

			} else if (itemRS.getString("computerType").equalsIgnoreCase("Laptop")) {
				comp = new Laptop(itemRS.getString("computer.serviceTag"),
						itemRS.getString("computer.componentMissing"), itemRS.getString("item.itemMake"),
						itemRS.getString("item.itemModel"), itemRS.getString("item.itemLocation"),
						itemRS.getString("computer.computerType"), itemRS.getInt("itemCapitalAsset"));

				laptopServiceTagCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("serviceTag"));
				laptopMakeCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerMake"));
				laptopModelCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerModel"));
				laptopLocCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerLocation"));
				laptopCompCol
						.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerComponentMissing"));
				laptopTable.getItems().add(comp);

			} else if (itemRS.getString("computerType").equalsIgnoreCase("All-In-One")) {
				comp = new AllOnePC(itemRS.getString("computer.serviceTag"),
						itemRS.getString("computer.componentMissing"), itemRS.getString("item.itemMake"),
						itemRS.getString("item.itemModel"), itemRS.getString("item.itemLocation"),
						itemRS.getString("computer.computerType"), itemRS.getInt("itemCapitalAsset"));

				allOneServiceTagCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("serviceTag"));
				allOneMakeCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerMake"));
				allOneModelCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerModel"));
				allOneLocCol.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerLocation"));
				allOneCompCol
						.setCellValueFactory(new PropertyValueFactory<Computer, String>("computerComponentMissing"));
				allOneTable.getItems().add(comp);

			}

		}
	}

	/*
	 * This method allows the double-click action on a tableview item to be selected and displayed on the edit page
	 */
	@FXML
	private void retrieveItems() throws SQLException {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

		String itemQuery = "SELECT * FROM Item";
		Statement itemStmt = con.createStatement();

		ResultSet itemRS = itemStmt.executeQuery(itemQuery);

		Item item = new Item();
		Item compItem = new Item();

		while (itemRS.next()) {

			if (!(itemRS.getString("itemType").equalsIgnoreCase("Desktop")
					|| itemRS.getString("itemType").equalsIgnoreCase("Laptop")
					|| itemRS.getString("itemType").equalsIgnoreCase("All-In-One")
					|| itemRS.getString("itemType").equalsIgnoreCase("Mouse")
					|| itemRS.getString("itemType").equalsIgnoreCase("Keyboard"))) {

				item = new Item(itemRS.getString("itemSerialNumber"), itemRS.getString("itemMake"),
						itemRS.getString("itemModel"), itemRS.getString("itemNotes"), itemRS.getString("itemLocation"),
						itemRS.getString("itemType"), itemRS.getInt("itemCapitalAsset"));

				itemSerialNumCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemSerialNumber"));
				itemServiceTagCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemServiceTag"));
				itemMakeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemMake"));
				itemModelCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemModel"));
				itemLocCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemLocation"));
				itemTypeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemType"));
				itemTable.getItems().add(item);

			}
		}
		itemRS.close();
		itemStmt.close();

		String compQuery = "SELECT Item.itemMake, item.itemModel, item.itemLocation, item.itemType, item.itemCapitalAsset"
				+ ", computer.serviceTag, computer.componentMissing" + " FROM Item " + "JOIN Computer "
				+ " WHERE Computer.computerID = Item.itemID";
		Statement compStmt = con.createStatement();
		ResultSet compRS = compStmt.executeQuery(compQuery);

		while (compRS.next()) {

			compItem = new Item(compRS.getString("computer.serviceTag"), compRS.getString("item.itemMake"),
					compRS.getString("item.itemModel"), compRS.getString("computer.componentMissing"),
					compRS.getString("item.itemLocation"), compRS.getInt("item.itemCapitalAsset"),
					compRS.getString("item.itemType"));

			itemSerialNumCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemSerialNumber"));
			itemServiceTagCol.setCellValueFactory(new PropertyValueFactory<Item, String>("serviceTag"));
			itemMakeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemMake"));
			itemModelCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemModel"));
			itemLocCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemLocation"));
			itemTypeCol.setCellValueFactory(new PropertyValueFactory<Item, String>("itemType"));
			itemTable.getItems().add(compItem);
		}
	}

	/*
	 * This method pulls mice from the database and displays in the mouse tab
	 */
	@FXML
	private void retrieveMouse() {

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			String itemQuery = "SELECT item.itemMake, mouse.mouseQuantity FROM Item JOIN Mouse WHERE mouse.mouseID = item.itemID";
			Statement itemStmt = con.createStatement();

			ResultSet itemRS = itemStmt.executeQuery(itemQuery);

			Mouse mouse = new Mouse();
			while (itemRS.next()) {
				mouse = new Mouse(itemRS.getString("item.itemMake"), itemRS.getInt("mouse.mouseQuantity"));
				mouseMakeCol.setCellValueFactory(new PropertyValueFactory<Mouse, String>("mouseMake"));
				mouseQuantityCol.setCellValueFactory(new PropertyValueFactory<Mouse, Integer>("mouseQuantity"));
				mouseTable.getItems().add(mouse);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * This method pulls keyboards from the database and displays them in the keyboard tab
	 */
	@FXML
	private void retrieveKeyboard() {

		try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			String itemQuery = "SELECT item.itemMake, keyboard.keyboardQuantity FROM Item JOIN Keyboard WHERE Keyboard.keyboardID = item.itemID";
			Statement itemStmt = con.createStatement();

			ResultSet itemRS = itemStmt.executeQuery(itemQuery);

			Keyboard keyboard = new Keyboard();
			while (itemRS.next()) {
				keyboard = new Keyboard(itemRS.getString("item.itemMake"), itemRS.getInt("keyboard.keyboardQuantity"));
				keyboardMakeCol.setCellValueFactory(new PropertyValueFactory<Keyboard, String>("keyboardMake"));
				keyboardQuantityCol
						.setCellValueFactory(new PropertyValueFactory<Keyboard, Integer>("keyboardQuantity"));
				keyboardTable.getItems().add(keyboard);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// A call method to display the Event Logs page
	@FXML
	private void callEventLogs() throws IOException {
		primaryStage = (Stage) eventLogButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("EventLog.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Event Logs");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// A call method to display the Home Page
	@FXML
	private void callHomepage() throws IOException {

		primaryStage = (Stage) homepageButton.getScene().getWindow();

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Homepage.fxml"));
		parentRoot = fxmlLoader.load();
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Home Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*************** Quick Edit Page ***************/
	// A call method to display the Quick Edit page
	@FXML
	private void callEditPage() throws IOException {

		primaryStage = (Stage) quickEditButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("QuickEdit.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Quick Edit Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*************** Item Creation Page ***************/
	// A call method to display the Create Item Page
	@FXML
	private void callCreatePage() throws IOException {
		primaryStage = (Stage) createItemButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("ItemCreation.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Item Creation Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*
	 * A method to change the background color of the menubar
	 */
	@FXML
	private void mouseHover() {
		if (homepageButton.isHover()) {
			homepageButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			createItemButton
					.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		} else if (createItemButton.isHover()) {
			createItemButton
					.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		} else if (quickEditButton.isHover()) {
			quickEditButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton
					.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		} else if (eventLogButton.isHover()) {
			eventLogButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton
					.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
	}
	
	/*
	 * A simple logout method
	 */

	@FXML
	private void logout() throws IOException {

		Alert alert = new Alert(AlertType.NONE, "Are you sure you want to log out?", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		if (alert.getResult().equals(ButtonType.OK)) {
			primaryStage = (Stage) homepageButton.getScene().getWindow();

			parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Login Page");
			primaryStage.show();
			if (primaryStage.isMaximized()) {
				primaryStage.setMaximized(false);
				primaryStage.setWidth(600);
				primaryStage.setHeight(400);
			}

		}
	}
}
