package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import javafx.beans.property.*;

// A class for creating an Item of type Printer
public class Printer extends Item {

	SimpleStringProperty printerType, itemMake, itemModel, itemNotes, itemLocation, serialNumber;
	SimpleIntegerProperty itemIsCapitalAsset;
	
	
	public Printer(String itemSerialNumber, String itemMake, String itemModel, String itemNotes, 
			String itemLocation, String itemType, int itemCapitalAsset) {
		super();
		this.printerType = new SimpleStringProperty(itemType);
		this.itemMake = new SimpleStringProperty(itemMake);
		this.itemModel = new SimpleStringProperty(itemModel);
		this.itemNotes = new SimpleStringProperty(itemNotes);
		this.itemLocation = new SimpleStringProperty(itemLocation);
		this.serialNumber = new SimpleStringProperty(itemSerialNumber);
		this.itemIsCapitalAsset = new SimpleIntegerProperty(itemCapitalAsset);
	}
	public Printer() {
		// TODO Auto-generated constructor stub
	}

	public String getItemType() {
		return printerType.get();
	}
	public void setItemType(String type) {
		printerType.set(type);
	}
	public String getItemMake() {
		return itemMake.get();
	}
	public void setItemMake(String make) {
		itemMake.set(make);
	}
	public String getItemModel() {
		return itemModel.get();
	}
	public void setItemModel(String model) {
		itemModel.set(model);
	}
	public String getItemNotes() {
		return itemNotes.get();
	}
	public void setItemNotes(String notes) {
		itemNotes.set(notes);
	}
	public String getItemLocation() {
		return itemLocation.get();
	}
	public void setItemLocation(String location) {
		itemLocation.set(location);
	}
	public String getItemSerialNumber() {
		return serialNumber.get();
	}
	public void setItemSerialNumber(String serialNum) {
		serialNumber.set(serialNum);
	}
	public int getItemIsCapitalAsset() {
		return this.itemIsCapitalAsset.get();
	}
	public void setItemIsCapitalAsset(int capAsset) {
		itemIsCapitalAsset.set(capAsset);
	}
	@Override
	public String toString() {
		return "Printer [itemType=" + printerType + ", itemMake=" + itemMake + ", itemModel=" + itemModel + ", itemNotes="
				+ itemNotes + ", itemLocation=" + itemLocation + ", itemSerialNumber=" + serialNumber
				+ ", itemIsCapitalAsset=" + itemIsCapitalAsset + "]";
	}
	
	
	
}
