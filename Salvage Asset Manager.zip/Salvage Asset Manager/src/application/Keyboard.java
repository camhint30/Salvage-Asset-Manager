
package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import javafx.beans.property.*;

/*
 * A class to create an Item of type keybaord
 */
public class Keyboard extends Item {

	SimpleStringProperty keyboardMake;
	SimpleIntegerProperty keyboardQuantity;

	public Keyboard() {

	}

	public Keyboard(String make, int quantity) {
		super();
		this.keyboardMake = new SimpleStringProperty(make);
		this.keyboardQuantity = new SimpleIntegerProperty(quantity);
	}
	
	public void setKeyboardQuantity(int quantity) {
		keyboardQuantity.set(quantity);
	}
	
	public int getKeyboardQuantity() {
		return keyboardQuantity.get();
	}
	public void setKeyboardMake(String make) {
		this.keyboardMake.set(make);
	}
	
	public String getKeyboardMake() {
		return keyboardMake.get();
	}
	
	@Override
	public String toString() {
		return "Keyboard/" + keyboardMake + "quantity: " + keyboardQuantity;
	}

}