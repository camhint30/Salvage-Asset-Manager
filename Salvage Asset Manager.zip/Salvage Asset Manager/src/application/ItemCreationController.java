package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.CheckBox;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ItemCreationController {

	Stage primaryStage = new Stage();
	Parent parentRoot;

	@FXML
	Button homepageButton, quickEditButton, createItemButton, eventLogButton, createPCButton, itemSelectButton,
			loginButton, computerSearchButton, createMouseBtn, createBtn;

	@FXML
	CheckBox capAssetCB, desktopCB, allOneCB, laptopCB;
	@FXML
	TextField serviceTagTF, makeTF, modelTF, serialNumberTF, keyboardBrandTextField, mouseBrandTF, serialNumTF, noteTF,
			capitalAssetCB, locationTF;
	@FXML
	MenuButton itemSelectMB;
	@FXML
	MenuItem pcMenuItem, keyboardMenuItem, printerMenuItem, otherMenuItem, mouseMenuItem, periphMenuItem;

	@FXML
	TextArea noteTA, missingComponentTA;

	@FXML
	Computer newComputer;

	@FXML
	static ArrayList<Computer> computerList = new ArrayList<Computer>();

	@FXML
	ObservableList<Computer> list = FXCollections.observableArrayList(computerList);

	@FXML
	static ArrayList<Event> eventList = new ArrayList<Event>();

	@FXML
	static ObservableList<Event> eList = FXCollections.observableArrayList(eventList);

	@FXML
	ArrayList<Keyboard> keyboardList = new ArrayList<Keyboard>();

	@FXML
	public static ArrayList<Computer> getList() {
		return computerList;
	}

	@FXML
	static ArrayList<Event> getEventList() {
		return eventList;
	}

	public ItemCreationController() {
		// Must leave blank
	}

	// A call method to display the Home Page
	@FXML
	private void callHomepage() throws IOException {

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Homepage.fxml"));
		parentRoot = fxmlLoader.load();

		primaryStage = (Stage) homepageButton.getScene().getWindow();

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Home Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*************** Quick Edit Page ***************/
	// A call method to display the Quick Edit page
	@FXML
	private void callEditPage() throws IOException {

		primaryStage = (Stage) quickEditButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("QuickEdit.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Quick Edit Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*************** Item Creation Page ***************/
	// A call method to display the Create Item Page
	@FXML
	private void callCreatePage() throws IOException {
		primaryStage = (Stage) createItemButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("ItemCreation.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Item Creation Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// A call method to display the Event Logs page
	@FXML
	private void callEventLogs() throws IOException {


		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EventLog.fxml"));
		parentRoot = fxmlLoader.load();
		primaryStage = (Stage) eventLogButton.getScene().getWindow();
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Event Logs");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);

	}

	DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	String date = dateFormat.format(new Date());
	Event e;

	@FXML
	static ArrayList<Printer> printerList = new ArrayList<Printer>();

	@FXML
	public static ArrayList<Printer> getPrinterList() {
		return printerList;
	}

	@FXML
	TextField printerNoteTF;

	@FXML
	private void pcCreatePage() throws IOException {

		primaryStage = (Stage) itemSelectButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("NewPC.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Create New PC");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*
	 * Change of stage method
	 */
	@FXML
	private void callKeyboardCreatePage() throws IOException {

		primaryStage = (Stage) itemSelectButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("NewKeyboard.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Create New Keyboard");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// change of stage method
	@FXML
	private void callPrinterCreatePage() throws IOException {
		primaryStage = (Stage) itemSelectButton.getScene().getWindow();
		parentRoot = FXMLLoader.load(getClass().getResource("NewPrinter.fxml"));
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Create New Printer");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// change of stage method
	@FXML
	private void callMouseCreatePage() throws IOException {
		primaryStage = (Stage) itemSelectButton.getScene().getWindow();
		parentRoot = FXMLLoader.load(getClass().getResource("NewMouse.fxml"));
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Create New Mouse");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// change of stage method
	@FXML
	private void callPeriphCreatePage() throws IOException {
		primaryStage = (Stage) itemSelectButton.getScene().getWindow();
		parentRoot = FXMLLoader.load(getClass().getResource("NewPeripheral.fxml"));
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Create New Peripheral");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// change of stage method
	@FXML
	private void callOtherCreatePage() throws IOException {
		primaryStage = (Stage) itemSelectButton.getScene().getWindow();
		parentRoot = FXMLLoader.load(getClass().getResource("NewOther.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Create New Other Asset");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	

	@FXML
	Keyboard newKeyboard;

	@FXML
	Mouse newMouse;

	Other otherAsset;

	@FXML
	TextField assetTypeTF, assetMakeTF, assetModelTF, assetSerialNumTF, assetLocationTF;

	@FXML
	TextArea assetNoteTA;

	@FXML
	CheckBox isCapAsset;

	@FXML
	Button assetConfirmBtn;

	// simple logout method
	@FXML
	private void logout() throws IOException {

		Alert alert = new Alert(AlertType.NONE, "Are you sure you want to log out?", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		if(alert.getResult().equals(ButtonType.OK)) {
			primaryStage = (Stage) itemSelectButton.getScene().getWindow();

			parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Login Page");
			primaryStage.show();
			if (primaryStage.isMaximized()) {
				primaryStage.setMaximized(false);
				primaryStage.setWidth(600);
				primaryStage.setHeight(400);
			}
			
		}
	}

	String user = LoginController.username;
	
	/*
	 * Method to insert the asset being created
	 */
	@FXML
	private void createPC() throws IOException, ClassNotFoundException, SQLException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			String itemQuery = "INSERT INTO Item (itemMake, itemModel, itemNotes, itemLocation,"
					+ "itemCapitalAsset, itemType)" + " VALUES (?,?,?,?,?,?)";

			String idQuery = "SELECT MAX(itemID) FROM Item";

			String compQuery = "INSERT INTO Computer (computerID, serviceTag, componentMissing, computerType)"
					+ " VALUES (?,?,?,?)";

			String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";

			Statement idStmt = con.createStatement();

			PreparedStatement itemStmt = con.prepareStatement(itemQuery);
			PreparedStatement compStmt = con.prepareStatement(compQuery);
			PreparedStatement eventStmt = con.prepareStatement(eventQuery);

			ResultSet rs = idStmt.executeQuery(idQuery);
			int id = 0;

			while (rs.next()) {
				id = rs.getInt("MAX(itemID)");
			}

			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
			int eID = 0;

			while (eRS.next())
				eID = eRS.getInt("MAX(eventID)");

			eventStmt.setInt(1, eID + 1);
			eventStmt.setString(2, date);

			String computerType = "";
			if (desktopCB.isSelected()) {
				itemStmt.setString(6, desktopCB.getText());
				compStmt.setString(4, desktopCB.getText());
				computerType = desktopCB.getText();
			}

			if (laptopCB.isSelected()) {
				itemStmt.setString(6, laptopCB.getText());
				compStmt.setString(4, laptopCB.getText());
				computerType = laptopCB.getText();
			}

			if (allOneCB.isSelected()) {
				itemStmt.setString(6, allOneCB.getText());
				compStmt.setString(4, allOneCB.getText());
				computerType = allOneCB.getText();
			}

			itemStmt.setString(1, makeTF.getText());
			itemStmt.setString(2, modelTF.getText());
			itemStmt.setString(3, noteTA.getText());
			itemStmt.setString(4, locationTF.getText());

			if (capAssetCB.isSelected())
				itemStmt.setInt(5, 1);
			else
				itemStmt.setInt(5, 0);

			compStmt.setString(2, serviceTagTF.getText());
			compStmt.setString(3, missingComponentTA.getText());

			itemStmt.execute();
			compStmt.setInt(1, id + 1);
			compStmt.execute();

			String eventAction = "Created " + computerType + ": Make: " + makeTF.getText() + " / Model: "
					+ modelTF.getText() + " / Service Tag: " + serviceTagTF.getText();
			eventStmt.setString(3, eventAction);
			eventStmt.setString(4, user);

			eventStmt.execute();

			Alert createAlert = new Alert(AlertType.INFORMATION);
			createAlert.setContentText("Item Created...");
			createAlert.showAndWait();

			callCreatePage();

		} catch (NumberFormatException nfe) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Field must be number...");
			serviceTagTF.setStyle("-fx-text-box-border: red");
			alert.show();
		} catch(SQLIntegrityConstraintViolationException cve) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Item with Service Tag already exists...");
			alert.showAndWait();
		} catch(SQLException s) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Computer type must be selected...");
			alert.showAndWait();
		} 
	}

	/*
	 * Method to insert into the database the asset being created
	 */
	@FXML
	private void createPrinter() throws IOException, ClassNotFoundException, SQLException {

		try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

		String itemQuery = "INSERT INTO Item (itemMake, itemModel, itemNotes, itemLocation,"
				+ "itemCapitalAsset, itemType, itemSerialNumber)" + " VALUES (?,?,?,?,?,?,?)";

		PreparedStatement itemStmt = con.prepareStatement(itemQuery);

		itemStmt.setString(1, makeTF.getText());
		itemStmt.setString(2, modelTF.getText());
		itemStmt.setString(3, noteTA.getText());
		itemStmt.setString(4, locationTF.getText());

		if (capAssetCB.isSelected())
			itemStmt.setInt(5, 1);
		else
			itemStmt.setInt(5, 0);

		itemStmt.setString(6, "Printer");
		itemStmt.setString(7, serialNumTF.getText());
		itemStmt.execute();

		String eIDQuery = "SELECT MAX(eventID) FROM Events";
		Statement eIDStmt = con.createStatement();
		ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
		int eID = 0;

		while (eRS.next())
			eID = eRS.getInt("MAX(eventID)");
		
		String eventQuery = "INSERT INTO Events (eventDate, eventAction, eventID, eventUsername) VALUES (?,?,?,?)";
		PreparedStatement eventStmt = con.prepareStatement(eventQuery);
		eventStmt.setString(1, date);
		String eventAction = "Created Printer: " + ": Make: " + makeTF.getText() + " / Model: " + modelTF.getText()
				+ " / Serial Number: " + serialNumTF.getText();
		eventStmt.setString(2, eventAction);
		eventStmt.setInt(3, eID+1);
		eventStmt.setString(4, user);
		eventStmt.execute();

		Alert createAlert = new Alert(AlertType.INFORMATION);
		createAlert.setContentText("Item Created...");
		createAlert.show();

		callCreatePage();
		} catch(Exception e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Item with Serial Number already exists...");
			alert.showAndWait();
		}

	}

	/*
	 * Method to insert into the database the asset being created
	 */
	@FXML
	private void createKeyboard() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			String itemQuery = "REPLACE INTO Item (itemType, itemMake) VALUES (?,?)";
			String keyboardQuery = "REPLACE INTO Keyboard (keyboardID, keyboardMake, keyboardQuantity) VALUES (?,?,?) ";

			String idQuery = "SELECT MAX(itemID) FROM Item";

			PreparedStatement itemStmt = con.prepareStatement(itemQuery);
			PreparedStatement mouseStmt = con.prepareStatement(keyboardQuery);

			Statement idStmt = con.createStatement();

			ResultSet rs = idStmt.executeQuery(idQuery);

			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);

			String checkQuery = "select item.itemID, keyboard.keyboardID from item " + "join keyboard where keyboard.keyboardMake ='"
					+ keyboardBrandTextField.getText() + "' and item.itemid = keyboard.keyboardID";
			Statement checkStmt = con.createStatement();
			ResultSet checkRS = checkStmt.executeQuery(checkQuery);

			if (checkRS.next()) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Keyboard Brand Already Exists...");
				alert.showAndWait();
			} else {
				int eID = 0;

				while (eRS.next())
					eID = eRS.getInt("MAX(eventID)");

				int id = 0;

				while (rs.next()) {
					id = rs.getInt("MAX(itemID)");
				}

				String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
				PreparedStatement eventStmt = con.prepareStatement(eventQuery);
				eventStmt.setInt(1, eID + 1);
				eventStmt.setString(2, date);
				String eventAction = "Created Keyboard: " + ": Make: " + keyboardBrandTextField.getText();
				eventStmt.setString(3, eventAction);
				eventStmt.setString(4, user);

				itemStmt.setString(1, "Keyboard");
				itemStmt.setString(2, keyboardBrandTextField.getText());

				itemStmt.execute();
				mouseStmt.setInt(1, id + 1);
				mouseStmt.setString(2, keyboardBrandTextField.getText());
				mouseStmt.setInt(3, 1);
				mouseStmt.execute();
				eventStmt.execute();

				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Keyboard Created!");
				alert.showAndWait();
				callCreatePage();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * Method to insert into the database the asset being created
	 */
	@FXML
	private void createMouse() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			String checkQuery = "select item.itemID, mouse.mouseID from item " + "join mouse where mouse.itemmake ='"
					+ mouseBrandTF.getText() + "' and item.itemid = mouse.mouseid";

			String itemQuery = "REPLACE INTO Item (itemType, itemMake) VALUES (?,?)";
			String mouseQuery = "REPLACE INTO Mouse (mouseID, itemMake, mouseQuantity) VALUES (?,?,?) ";
			String idQuery = "SELECT MAX(itemID) FROM Item";

			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);

			Statement checkStmt = con.createStatement();
			ResultSet checkRS = checkStmt.executeQuery(checkQuery);

			if (checkRS.next()) {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Mouse Brand Already Exists...");
				alert.showAndWait();
			} else {
				int eID = 0;

				while (eRS.next())
					eID = eRS.getInt("MAX(eventID)");

				PreparedStatement itemStmt = con.prepareStatement(itemQuery);
				PreparedStatement mouseStmt = con.prepareStatement(mouseQuery);

				Statement idStmt = con.createStatement();

				ResultSet rs = idStmt.executeQuery(idQuery);

				int id = 0;

				while (rs.next()) {
					id = rs.getInt("MAX(itemID)");
				}

				String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
				PreparedStatement eventStmt = con.prepareStatement(eventQuery);
				eventStmt.setInt(1, eID + 1);
				eventStmt.setString(2, date);
				String eventAction = "Created Mouse: " + ": Make: " + mouseBrandTF.getText();
				eventStmt.setString(3, eventAction);
				eventStmt.setString(4, user);

				itemStmt.setString(1, "Mouse");
				itemStmt.setString(2, mouseBrandTF.getText());

				itemStmt.execute();
				mouseStmt.setInt(1, id + 1);
				mouseStmt.setString(2, mouseBrandTF.getText());
				mouseStmt.setInt(3, 1);
				mouseStmt.execute();
				eventStmt.execute();

				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Mouse Created!");
				alert.showAndWait();
				callCreatePage();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/*
	 * Method to insert into the database the asset being created
	 */

	@FXML
	private void createOtherAsset() throws SQLException, ClassNotFoundException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
			String query = "";
			PreparedStatement pStatement = null;

			query = " insert into Item (itemMake, itemModel, itemNotes, itemLocation, itemCapitalAsset, itemType,"
					+ "itemSerialNumber)" + " values (?, ?, ?, ?, ?, ?, ?)";
			pStatement = con.prepareStatement(query);

			pStatement.setString(1, assetMakeTF.getText());
			pStatement.setString(2, assetModelTF.getText());
			pStatement.setString(3, assetNoteTA.getText());
			pStatement.setString(4, assetLocationTF.getText());

			if (isCapAsset.isSelected()) {
				pStatement.setInt(5, 1);
			} else
				pStatement.setInt(5, 0);

			pStatement.setString(6, assetTypeTF.getText());
			pStatement.setString(7, assetSerialNumTF.getText());

			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
			int eID = 0;

			while (eRS.next())
				eID = eRS.getInt("MAX(eventID)");


			String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
			PreparedStatement eventStmt = con.prepareStatement(eventQuery);
			eventStmt.setInt(1, eID + 1);
			eventStmt.setString(2, date);
			String eventAction = "Created: " + assetMakeTF.getText() + ": Make: " + assetMakeTF.getText()
					+ " / Model:  " + assetModelTF.getText() + " / Serial Number: " + assetSerialNumTF.getText();
			eventStmt.setString(3, eventAction);
			eventStmt.setString(4, user);

			pStatement.execute();
			eventStmt.execute();
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Asset Created!");
			alert.show();
			callCreatePage();
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Item with Serial Number already exists...");
			alert.showAndWait();

		}

	}
 
	/*
	 * Method to insert into the database the asset being created
	 */
	@FXML
	private void createPeriphAsset() throws ClassNotFoundException, SQLException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
			String query = "";
			PreparedStatement pStatement = null;

			query = " insert into Item (itemMake, itemModel, itemNotes, itemLocation, itemCapitalAsset, itemType,"
					+ "itemSerialNumber)" + " values (?, ?, ?, ?, ?, ?, ?)";
			pStatement = con.prepareStatement(query);

			pStatement.setString(1, assetMakeTF.getText());
			pStatement.setString(2, assetModelTF.getText());
			pStatement.setString(3, assetNoteTA.getText());
			pStatement.setString(4, locationTF.getText());
			if (isCapAsset.isSelected()) {
				pStatement.setInt(5, 1);
			} else
				pStatement.setInt(5, 0);
			pStatement.setString(6, "Peripheral");
			pStatement.setString(7, assetSerialNumTF.getText());

			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
			int eID = 0;

			while (eRS.next())
				eID = eRS.getInt("MAX(eventID)");

			String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
			PreparedStatement eventStmt = con.prepareStatement(eventQuery);
			eventStmt.setInt(1, eID + 1);
			eventStmt.setString(2, date);
			String eventAction = "Created: " + assetMakeTF.getText() + ": Make: " + assetMakeTF.getText()
					+ " / Model:  " + assetModelTF.getText() + " / Serial Number: " + assetSerialNumTF.getText();
			eventStmt.setString(3, eventAction);
			eventStmt.setString(4, user);
			pStatement.execute();
			eventStmt.execute();

			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Asset Created!");
			alert.show();
			callCreatePage();
		} catch (Exception e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText("Item with Serial Number already exisits...");
			alert.showAndWait();

		}
	}

	// method to get the page from the menubar the user selects
	@FXML
	private void userCreateSelection() throws IOException {

		if (itemSelectMB.getText().equals(keyboardMenuItem.getText()))
			callKeyboardCreatePage();

		if (itemSelectMB.getText().equals(pcMenuItem.getText()))
			pcCreatePage();

		if (itemSelectMB.getText().equals(printerMenuItem.getText()))
			callPrinterCreatePage();

		if (itemSelectMB.getText().equals(mouseMenuItem.getText()))
			callMouseCreatePage();

		if (itemSelectMB.getText().equals(otherMenuItem.getText()))
			callOtherCreatePage();

		if (itemSelectMB.getText().equals(periphMenuItem.getText()))
			callPeriphCreatePage();
	}

	/*
	 * Methods below append the text for the item selected
	 */
	@FXML
	private void appendToKeyboard() {

		itemSelectMB.setText(keyboardMenuItem.getText());
	}

	@FXML
	private void appendToPC() {
		itemSelectMB.setText(pcMenuItem.getText());
	}

	@FXML
	private void appendToPrinter() {
		itemSelectMB.setText(printerMenuItem.getText());
	}

	@FXML
	private void appendToMouse() {
		itemSelectMB.setText(mouseMenuItem.getText());
	}

	@FXML
	private void appendToPeriph() {
		itemSelectMB.setText(periphMenuItem.getText());
	}

	@FXML
	private void appendToOther() {
		itemSelectMB.setText(otherMenuItem.getText());
	}

	/*
	 * Methods below change the checkboxes not allowing the user to select more than one
	 */
	@FXML
	private String laptopCBToggle() {
		if (laptopCB.isSelected() == true) {
			desktopCB.setSelected(false);
			allOneCB.setSelected(false);
			return "Laptop";
		}
		return null;
	}

	@FXML
	private String allOneCBToggle() {
		if (allOneCB.isSelected() == true) {
			desktopCB.setSelected(false);
			laptopCB.setSelected(false);
			return "All-In-One";
		}
		return null;

	}

	@FXML
	private String desktopCBToggle() {

		if (desktopCB.isSelected() == true) {
			laptopCB.setSelected(false);
			allOneCB.setSelected(false);
			return "Desktop";
		}
		return null;
	}
	
	/*
	 * Method below changes the color of the menu bars
	 */
	@FXML
	private void mouseHover() {
		if(homepageButton.isHover()) {
			homepageButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(createItemButton.isHover()) {
			createItemButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(quickEditButton.isHover()) {
			quickEditButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(eventLogButton.isHover()) {
			eventLogButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
	}

}
