package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class QuickEditController {

	Stage primaryStage = new Stage();
	Parent parentRoot;
	
	@FXML
	Button homepageButton, quickEditButton, createItemButton, eventLogButton,
	fiveDecreaseBtn, oneDecreaseBtn, oneIncreaseBtn, fiveIncreaseBtn, confirmBtn;
	
	@FXML
	TextField currentTF, newTF, changeTF, assetSerialNumTF;
	
	@FXML
	MenuButton itemSelectMB;
	
	@FXML
	Label itemTypeLbl;
	
	@FXML
	MenuButton brandSelectMB;
	
	@FXML
	MenuItem keyboardMenuItem, mouseMenuItem, printerMenuItem, periphMenuItem, otherMenuItem;

	
	@FXML
	ArrayList<MenuItem> menu = new ArrayList<MenuItem>();
	
	@FXML
	MenuItem[] keyboardMenu;

	@FXML
	MenuItem[] mouseMenu;
	
	@FXML
	TextField serviceTagTF;
	
	@FXML
	TextField editServiceTF;
	
	DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	String date = dateFormat.format(new Date());
	
	public QuickEditController() {
		
	}
	
	@FXML
	ToggleButton editItemButton;
	
	@FXML
	Label newQLbl, currentLbl, changeLbl;
	
	@FXML
	MenuItem computerMenuItem;
	
	@FXML
	Label amountLbl;
	
	
	@FXML
	Label serviceTagLbl;
	
	// Hides textboxes, checkboxes and fields that are displayed
	@FXML
	private void hideEditItems() {
		try {
			oneDecreaseBtn.setVisible(false);
			changeLbl.setVisible(false);
			newQLbl.setVisible(false);
			currentLbl.setVisible(false);
			newTF.setVisible(false);
			changeTF.setVisible(false);
			currentTF.setVisible(false);
			itemTypeLbl.setVisible(false);
			brandSelectMB.setVisible(false);
			fiveIncreaseBtn.setVisible(false);
			fiveDecreaseBtn.setVisible(false);
			confirmBtn.setVisible(false);
			oneIncreaseBtn.setVisible(false);
			amountLbl.setVisible(false);
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	// displays items that are hidden
	@FXML
	private void showItems() {
		oneDecreaseBtn.setVisible(true);
		changeLbl.setVisible(true);
		newQLbl.setVisible(true);
		currentLbl.setVisible(true);
		newTF.setVisible(true);
		changeTF.setVisible(true);
		currentTF.setVisible(true);
		itemTypeLbl.setVisible(true);
		brandSelectMB.setVisible(true);
		fiveIncreaseBtn.setVisible(true);
		fiveDecreaseBtn.setVisible(true);
		confirmBtn.setVisible(true);
		oneIncreaseBtn.setVisible(true);
		amountLbl.setVisible(true);

		editItemBtn.setVisible(false);
		editServiceTF.setVisible(false);
		serviceTagLbl.setVisible(false);
	}
	
	@FXML
	Button editItemBtn;
	
	int serviceTag;
	
	/*
	 * The methods below append the menuitem text to the text selected
	 */
	@FXML
	private void appendToPC() {
		itemSelectMB.setText(computerMenuItem.getText());
		editAssetButton.setVisible(false);
		editServiceTF.setVisible(true);
		serviceTagLbl.setVisible(true);
		serviceTagLbl.setText("ServiceTag");
		hideEditItems();
		
	}
	
	@FXML
	private void appendToPeriph() {
		itemSelectMB.setText(periphMenuItem.getText());
		editAssetButton.setVisible(false);
		editServiceTF.setVisible(true);
		serviceTagLbl.setVisible(true);
		serviceTagLbl.setText("Serial Number:");
		hideEditItems();
	}
	@FXML
	Button editAssetButton;
	@FXML
	private void appendToPrinter() {
		itemSelectMB.setText(printerMenuItem.getText());
		editAssetButton.setVisible(false);
		editServiceTF.setVisible(true);
		serviceTagLbl.setVisible(true);
		serviceTagLbl.setText("Serial Number:");
		hideEditItems();
	}
	
	@FXML
	private void appendToOther() {
		itemSelectMB.setText(otherMenuItem.getText());
		editServiceTF.setVisible(true);
		serviceTagLbl.setVisible(true);
		serviceTagLbl.setText("Serial Number:");
		hideEditItems();
	}
	
	@FXML
	private void appendToKeyboard() throws SQLException {
		showItems();
		itemSelectMB.setText(keyboardMenuItem.getText());
		itemTypeLbl.setText(keyboardMenuItem.getText());
		
		//brandSelectMB.getItems().clear();
		getKeyboardBrandList();
	}
	
	@FXML
	private void appendToMouse() throws SQLException {
		showItems();
		itemSelectMB.setText(mouseMenuItem.getText());
		itemTypeLbl.setText(mouseMenuItem.getText());
		
		getMouseBrandList();
	}
	
	@FXML
	static Computer comp;
	
	/*
	 * Methods for calling the pages selected
	 */
	@FXML
	private void getEditItem() throws IOException {
		primaryStage = (Stage) quickEditButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("EditItem.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Edit Item Page");
		primaryStage.show();
		
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	@FXML
	private void getComputerEdit() throws IOException {	
			primaryStage = (Stage) quickEditButton.getScene().getWindow();
			
			parentRoot = FXMLLoader.load(getClass().getResource("EditPC.fxml"));
			
			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Edit Computer Page");
			primaryStage.show();
			
			if(primaryStage.isMaximized())
				primaryStage.setMaximized(true);
	
	}


	@FXML
	static Item item;
	
	int serialNum;
	
	/*
	 * Method for getting the type of the menubar
	 */
	@FXML
	private void getEditSelection() throws ClassNotFoundException, IOException, SQLException {
		
		if(itemSelectMB.getText().equals("Computer"))
			retrieveComputer();
		if(itemSelectMB.getText().equals("Other") || itemSelectMB.getText().equals("Peripheral") ||
				itemSelectMB.getText().equals("Printer"))
			retrieveItem();
	}
	
	/*
	 * Method for accessing database to select the appropriate item with the correct serial number and displaying it
	 */
	@FXML
	private void retrieveItem() throws IOException, ClassNotFoundException, SQLException {
		
		serialNum = Integer.valueOf(editServiceTF.getText());
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		String query = "SELECT * FROM Item WHERE itemSerialNumber= '" + serialNum + "'";
		
		Statement stmnt = con.createStatement();
		
		ResultSet editRS = stmnt.executeQuery(query);

		while(editRS.next()) {
			item = new Item(editRS.getString("itemSerialNumber"), editRS.getString("itemMake"),
					editRS.getString("itemModel"), editRS.getString("itemNotes"),
					editRS.getString("itemLocation"), editRS.getString("itemType"),
					editRS.getInt("itemCapitalAsset"));
		}
		
		getEditItem();
	}
	
	// Method for retrieving from the database the item with the appropriate service tag
	@FXML
	private void retrieveComputer() throws IOException, ClassNotFoundException, SQLException {
		
		serviceTag = Integer.valueOf(editServiceTF.getText());
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		String query = "SELECT Item.itemMake, item.itemModel, item.itemLocation, item.itemType, item.itemCapitalAsset," +
				 "Computer.serviceTag, computer.componentMissing FROM Item JOIN Computer WHERE Computer.computerID"+
				 " = Item.itemID AND computer.serviceTag= '" + serviceTag + "'";
		
		Statement stmnt = con.createStatement();
		
		ResultSet editRS = stmnt.executeQuery(query);
		while(editRS.next()) {
			if(stmnt.getResultSet().getString("Item.itemType").equals("Desktop")) {
				comp = new Desktop(editRS.getString("Computer.serviceTag"), editRS.getString("Computer.componentMissing"),
						editRS.getString("Item.itemMake"), editRS.getString("Item.itemModel"),
						editRS.getString("Item.itemLocation"), editRS.getString("Item.itemType"),
						editRS.getInt("Item.itemCapitalAsset"));
			}
			if(stmnt.getResultSet().getString("Item.itemType").equals("Laptop")) {
				comp = new Desktop(editRS.getString("Computer.serviceTag"), editRS.getString("Computer.componentMissing"),
						editRS.getString("Item.itemMake"), editRS.getString("Item.itemModel"),
						editRS.getString("Item.itemLocation"), editRS.getString("Item.itemType"),
						editRS.getInt("Item.itemCapitalAsset"));
			}
			
			if(stmnt.getResultSet().getString("Item.itemType").equals("All-In-One")) {
				comp = new Desktop(editRS.getString("Computer.serviceTag"), editRS.getString("Computer.componentMissing"),
						editRS.getString("Item.itemMake"), editRS.getString("Item.itemModel"),
						editRS.getString("Item.itemLocation"), editRS.getString("Item.itemType"),
						editRS.getInt("Item.itemCapitalAsset"));
			}
		}
		getComputerEdit();
		
		}
		
	
	// Method for getting the brands created in the database 
	@FXML
	private void getMouseBrandList() throws SQLException {
		
		brandSelectMB.getItems().clear();
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		String mouseQuery = "SELECT mouse.itemMake, mouse.mouseQuantity"
				+ " FROM Mouse JOIN Item WHERE item.itemID = mouse.mouseID";
	

		String countQuery = mouseQuery;
		Statement mouseStmt = con.createStatement();
		Statement countStmt = con.createStatement();
	
		ResultSet mouseRS = mouseStmt.executeQuery(mouseQuery);
		ResultSet countRS = countStmt.executeQuery(countQuery);

		int size = 0;
		while(countRS.next()) {
			size++;
		}
		mouseMenu = new MenuItem[size];
		
		int i = 0;
		while(mouseRS.next()) {
			mouseMenu[i] = new MenuItem(mouseRS.getString("mouse.itemMake"));
			brandSelectMB.getItems().add(mouseMenu[i]);
			i++;
		}
		
		for(MenuItem m : mouseMenu) {
			m.setOnAction(e -> {
				brandSelectMB.setText(m.getText());
				getMouseQuantities();
			});
		}
		
		updateMouseQuantities();
	}
	
	// Method for getting the brands created in the database
	
	@FXML
	private void getKeyboardBrandList() throws SQLException {
	
		brandSelectMB.getItems().clear();
		
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		String keyboardQuery = "SELECT Keyboard.keyboardMake, Keyboard.keyboardQuantity"
				+ " FROM Keyboard JOIN Item WHERE item.itemID = Keyboard.keyboardID";

		String countQuery = keyboardQuery;
		Statement keyboardStmt = con.createStatement();
		Statement countStmt = con.createStatement();
	
		ResultSet keyboardRS = keyboardStmt.executeQuery(keyboardQuery);
		ResultSet countRS = countStmt.executeQuery(countQuery);

		int size = 0;
		while(countRS.next()) {
			size++;
		}
		keyboardMenu = new MenuItem[size];
		
		int i = 0;
		while(keyboardRS.next()) {
			keyboardMenu[i] = new MenuItem(keyboardRS.getString("Keyboard.keyboardMake"));
			brandSelectMB.getItems().add(keyboardMenu[i]);
			i++;
		}
		
		for(MenuItem m : keyboardMenu) {
			m.setOnAction(e -> {
				brandSelectMB.setText(m.getText());
				getKeyboardQuantities();
			});
		}
		updateKeyboardQuantities();
		
	}

	
	// Method for updating the quantities in the databse table of mouse
	private void updateMouseQuantities() {
		
		try {
		
		
		
		confirmBtn.setOnAction(e -> {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
				
				String mouseQuery = "UPDATE Item, Mouse"
						+ " SET Mouse.mouseQuantity = " + newTF.getText()
						+ " WHERE Mouse.mouseID = Item.itemID"
						+ " AND mouse.itemMake = '" + brandSelectMB.getText() + "'";
				
				PreparedStatement mouseStmt = con.prepareStatement(mouseQuery);
				
				String idQuery = "SELECT MAX(eventID) FROM Events";
				
				Statement idStmt = con.createStatement();
				
				ResultSet rs = idStmt.executeQuery(idQuery);

				int id = 0;
				
				while(rs.next()) {
					id = rs.getInt("MAX(eventID)");
				}
				
				String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction) VALUES (?,?,?)";
				PreparedStatement eventStmt = con.prepareStatement(eventQuery);
				
				eventStmt.setInt(1, id+1);
				eventStmt.setString(2, date);		
				
				String eventAction = "Updated Mouse: " + ": Make: " + brandSelectMB.getText() + " Quantitiy: " 
				+ newTF.getText() ;
				
				eventStmt.setString(3, eventAction);
				

				eventStmt.execute();
				mouseStmt.execute();
				
				
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Quantites updated...");
				alert.show();
				newTF.setText(String.valueOf(0));
				changeTF.setText(String.valueOf(0));
				currentTF.setText(String.valueOf(0));
				itemSelectMB.setText("Select Item...");
				brandSelectMB.setText("Select Brand...");
			} catch (SQLException | ClassNotFoundException e1) {
				e1.printStackTrace();
			}
			
		});

		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	//method for updating the quantities of the table keyboard in the database
	private void updateKeyboardQuantities() {
		try {
			
			
			
			confirmBtn.setOnAction(e -> {
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
					
					String keyboardQuery = "UPDATE Item, Keyboard"
							+ " SET Keyboard.keyboardQuantity = " + newTF.getText()
							+ " WHERE Keyboard.keyboardID = Item.itemID"
							+ " AND Keyboard.keyboardMake = '" + brandSelectMB.getText() + "'";
					
					PreparedStatement keyboardStmt = con.prepareStatement(keyboardQuery);
					
					String idQuery = "SELECT MAX(eventID) FROM Events";
					
					Statement idStmt = con.createStatement();
					
					ResultSet rs = idStmt.executeQuery(idQuery);

					int id = 0;
					
					while(rs.next()) {
						id = rs.getInt("MAX(eventID)");
					}
					
					String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction) VALUES (?,?,?)";
					PreparedStatement eventStmt = con.prepareStatement(eventQuery);
					
					eventStmt.setInt(1, id+1);
					eventStmt.setString(2, date);		
					
					String eventAction = "Updated Keyboard: " + ": Make: " + brandSelectMB.getText() + " Quantitiy: " 
					+ newTF.getText() ;
					
					eventStmt.setString(3, eventAction);
					

					eventStmt.execute();
					keyboardStmt.execute();
					
					
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setContentText("Quantites updated...");
					alert.show();
					newTF.setText(String.valueOf(0));
					changeTF.setText(String.valueOf(0));
					currentTF.setText(String.valueOf(0));
					itemSelectMB.setText("Select Item...");
					brandSelectMB.setText("Select Brand...");
				} catch (SQLException | ClassNotFoundException e1) {
					e1.printStackTrace();
				}
				
			});

			} catch(Exception e) {
				e.printStackTrace();
			}
	}

	// method for recieving the quantities of the table mouse in the database
	private void getMouseQuantities() {
		
		try {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		String mouseQuery = "SELECT mouse.itemMake, mouse.mouseQuantity"
				+ " FROM Mouse JOIN Item WHERE mouse.itemMake = '" + brandSelectMB.getText().toLowerCase() + "'";
		
		Statement mouseStmt = con.createStatement();
		ResultSet mouseRS = mouseStmt.executeQuery(mouseQuery);
		
		while(mouseRS.next()) {
			currentTF.setText(String.valueOf(mouseRS.getInt("mouse.mouseQuantity")));
		}
		} catch(Exception e) {
			e.printStackTrace();
		}		
	}
	
	
	// method for recieving the quantities of the table keyboard in the database
	private void getKeyboardQuantities() {
		
		try {
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		String keyboardQuery = "SELECT Keyboard.keyboardMake, Keyboard.keyboardQuantity"
				+ " FROM Keyboard JOIN Item WHERE Keyboard.keyboardMake = '" + brandSelectMB.getText().toLowerCase() + "'";
		
		
		Statement keyboardStmt = con.createStatement();
		ResultSet keyboardRS = keyboardStmt.executeQuery(keyboardQuery);
		
		while(keyboardRS.next()) {
			currentTF.setText(String.valueOf(keyboardRS.getInt("Keyboard.keyboardQuantity")));
		}
		} catch(Exception e) {
			e.printStackTrace();
		}		
		
	}
	
	/*
	 * The below methods update the quantities in the textfield by the respective button pressed
	 */
	@FXML
	private void increaseOne() {
		int changeValue = Integer.valueOf(changeTF.getText());
		changeValue++;
		int newValue = 0;
		int currentValue = Integer.valueOf(currentTF.getText());
		newValue = currentValue + changeValue;
		
		
		changeTF.setText(String.valueOf(changeValue));
		newTF.setText(String.valueOf(newValue));
	}
	
	@FXML
	private void decreaseOne() {
		int changeValue = Integer.valueOf(changeTF.getText());
		changeValue--;
		int newValue = 0;
		int currentValue = Integer.valueOf(currentTF.getText());
		newValue = currentValue + changeValue;
		
		
		changeTF.setText(String.valueOf(changeValue));
		newTF.setText(String.valueOf(newValue));
	}
	
	@FXML
	private void increaseFive() {
		int changeValue = Integer.valueOf(changeTF.getText());
		changeValue += 5;
		int newValue = 0;
		int currentValue = Integer.valueOf(currentTF.getText());
		newValue = currentValue + changeValue;
		
		
		changeTF.setText(String.valueOf(changeValue));
		newTF.setText(String.valueOf(newValue));
	}
	
	@FXML
	private void decreaseFive() {
		int changeValue = Integer.valueOf(changeTF.getText());
		changeValue -= 5;
		int newValue = 0;
		int currentValue = Integer.valueOf(currentTF.getText());
		newValue = currentValue + changeValue;
		
		
		changeTF.setText(String.valueOf(changeValue));
		newTF.setText(String.valueOf(newValue));
	}
	
	// A call method to display the Home Page
	@FXML
	private void callHomepage() throws IOException {
		
		primaryStage = (Stage) homepageButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("Homepage.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Home Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	/*************** Quick Edit Page ***************/
	// A call method to display the Quick Edit page
	@FXML
	private void callEditPage() throws IOException {
		
		primaryStage = (Stage) quickEditButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("QuickEdit.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Quick Edit Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	/*************** Item Creation Page ***************/
	// A call method to display the Create Item Page
	@FXML
	private void callCreatePage() throws IOException {
		primaryStage = (Stage) createItemButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("ItemCreation.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Item Creation Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	// A call method to display the Event Logs page
	@FXML
	private void callEventLogs() throws IOException {
		primaryStage = (Stage) eventLogButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("EventLog.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Event Logs");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	// a simple logout method
	@FXML
	private void logout() throws IOException {

		Alert alert = new Alert(AlertType.NONE, "Are you sure you want to log out?", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		if(alert.getResult().equals(ButtonType.OK)) {
			primaryStage = (Stage) quickEditButton.getScene().getWindow();

			parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Login Page");
			primaryStage.show();
			if (primaryStage.isMaximized()) {
				primaryStage.setMaximized(false);
				primaryStage.setWidth(600);
				primaryStage.setHeight(400);
			}
			
		}
	}
	
	// the method below changes the color of the menu bar
	@FXML
	private void mouseHover() {
		if(homepageButton.isHover()) {
			homepageButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(createItemButton.isHover()) {
			createItemButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(quickEditButton.isHover()) {
			quickEditButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(eventLogButton.isHover()) {
			eventLogButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
	}
}
