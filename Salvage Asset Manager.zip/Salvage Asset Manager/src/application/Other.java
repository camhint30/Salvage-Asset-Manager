package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import javafx.beans.property.*;

// A Class for creating an Item of type Other
public class Other extends Item {

	SimpleStringProperty itemType, itemMake, itemModel, itemNotes, itemLocation, itemSerialNumber;
	SimpleIntegerProperty itemIsCapitalAsset;
	
	
	public Other(String itemSerialNumber, String itemMake, String itemModel, String itemNotes, 
			String itemLocation, String itemType, int itemCapitalAsset) {
		super();
		this.itemType = new SimpleStringProperty(itemType);
		this.itemMake = new SimpleStringProperty(itemMake);
		this.itemModel = new SimpleStringProperty(itemModel);
		this.itemNotes = new SimpleStringProperty(itemNotes);
		this.itemLocation = new SimpleStringProperty(itemLocation);
		this.itemSerialNumber = new SimpleStringProperty(itemSerialNumber);
	}
	public Other() {
		// TODO Auto-generated constructor stub
	}

	public String getItemType(String type) {
		return itemType.get();
	}
	public void setItemType(String type) {
		itemType.set(type);
	}
	public String getItemMake() {
		return itemMake.get();
	}
	public void setItemMake(String make) {
		itemMake.set(make);
	}
	public String getItemModel() {
		return itemModel.get();
	}
	public void setItemModel(String model) {
		itemModel.set(model);
	}
	public String getItemNotes() {
		return itemNotes.get();
	}
	public void setItemNotes(String notes) {
		itemNotes.set(notes);
	}
	public String getItemLocation() {
		return itemLocation.get();
	}
	public void setItemLocation(String location) {
		itemLocation.set(location);
	}
	public String getItemSerialNumber() {
		return itemSerialNumber.get();
	}
	public void setItemSerialNumber(String serialNum) {
		itemSerialNumber.set(serialNum);
	}
	public int getItemIsCapitalAsset() {
		return itemIsCapitalAsset.get();
	}
	public void setItemIsCapitalAsset(int capAsset) {
		itemIsCapitalAsset.set(capAsset);
	}
	@Override
	public String toString() {
		return "Item [itemType=" + itemType + ", itemMake=" + itemMake + ", itemModel=" + itemModel + ", itemNotes="
				+ itemNotes + ", itemLocation=" + itemLocation + ", itemSerialNumber=" + itemSerialNumber
				+ ", itemIsCapitalAsset=" + itemIsCapitalAsset + "]";
	}
	
	
	
}
