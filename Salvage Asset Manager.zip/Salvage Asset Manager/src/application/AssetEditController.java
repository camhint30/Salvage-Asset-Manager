package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class AssetEditController implements Initializable{
	
	Stage primaryStage = new Stage();
	Parent parentRoot;
	
	@FXML
	Button homepageButton, quickEditButton, createItemButton, eventLogButton;
	
	@FXML
	ObservableList<Printer> pList = FXCollections.observableArrayList(ItemCreationController.printerList);
	
	@FXML
	ObservableList<Computer> list = FXCollections.observableArrayList(ItemCreationController.computerList);
	
	@FXML
	ObservableList<Event> eList = FXCollections.observableArrayList(ItemCreationController.eventList);
	
	@FXML
	CheckBox desktopCB, laptopCB, allOneCB, isCapAsset;

	Computer computer = QuickEditController.comp;
	
	@FXML
	TextField assetTypeTF, assetSerialNumTF, assetMakeTF, assetModelTF, assetLocationTF;
	
	DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	String date = dateFormat.format(new Date());
	
	@FXML
	TextArea assetNoteTA;
	
	Item item = QuickEditController.item;
	
	public AssetEditController() {
		
	}
	
	// Runs as soon as page is called
	/*
	 * (non-Javadoc)
	 * @see javafx.fxml.Initializable#initialize(java.net.URL, java.util.ResourceBundle)
	 * This method starts as the page is called and fills the fields with the items fields from the databse
	 */
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

			// query to select the item with the serial number from the database
			String query = "SELECT * FROM Item WHERE itemSerialNumber = '" + item.getItemSerialNumber() + "'";
			Statement stmnt = con.createStatement();
			
			ResultSet editRS = stmnt.executeQuery(query);
			
			// Sets the fields for the Item table in MySQL database
			while(editRS.next()) {
				assetTypeTF.setText(editRS.getString("itemType"));
				assetSerialNumTF.setText(editRS.getString("itemSerialNumber"));
				assetMakeTF.setText(editRS.getString("itemMake"));
				assetModelTF.setText(editRS.getString("itemModel"));
				assetLocationTF.setText(editRS.getString("itemLocation"));
				assetNoteTA.setText(editRS.getString("itemNotes"));
				
				if(editRS.getInt("itemCapitalAsset") == 1)
					isCapAsset.setSelected(true);
				}
			
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	String user = LoginController.username;
	
	// Method to delete the item
	@FXML
	private void deleteItem() throws ClassNotFoundException, SQLException, IOException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		// Query to delete Item in database by item serial number
		String query = "DELETE FROM Item WHERE itemSerialNumber = " + item.getItemSerialNumber();
	
		Statement stmt = con.prepareStatement(query);
		
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("Are you sure you want to delete this item?");
		Optional<ButtonType> result = alert.showAndWait();
		ButtonType button = result.orElse(ButtonType.CANCEL);
		
		if(button == ButtonType.OK)
			stmt.executeUpdate(query);
		
		int eID = 0;
		String eIDQuery = "SELECT MAX(eventID) FROM Events";
		Statement eIDStmt = con.createStatement();
		ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
		while(eRS.next()) {
			eID = eRS.getInt("MAX(eventID)") + 1;
		}
		
		// Inserts into Events at the max event ID + 1
		String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
		PreparedStatement eventStmt = con.prepareStatement(eventQuery);
		eventStmt.setInt(1, eID);
		eventStmt.setString(2, date);
		String eventAction = "Deleted: " + assetTypeTF.getText() + ": Make: " + assetMakeTF.getText() + " / Model: " + assetModelTF.getText()
				+ " / Serial Number: " + assetSerialNumTF.getText();
		eventStmt.setString(3, eventAction);
		eventStmt.setString(4, user);
		eventStmt.execute();
		callHomepage();
		
		
	}

	// Method for submitting the edit
	@FXML
	private void submitEdit() throws ClassNotFoundException, SQLException {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

		try {
		int capAsset = 0;
		if(isCapAsset.isSelected())
			capAsset = 1;
		String editQuery = "UPDATE Item SET itemMake ='" + assetMakeTF.getText() + "', itemModel = '" + assetModelTF.getText() +
				"', itemType='" + assetTypeTF.getText() + "',itemLocation='" + assetLocationTF.getText() + 
				"', itemSerialNumber='" + assetSerialNumTF.getText() + "', itemNotes='" + assetNoteTA.getText() +
				"', itemCapitalAsset=" + capAsset + " WHERE itemSerialNumber=" + item.getItemSerialNumber();
		PreparedStatement pStatement = con.prepareStatement(editQuery);
		
		pStatement.execute();
		
		int eID = 0;
		String eIDQuery = "SELECT MAX(eventID) FROM Events";
		Statement eIDStmt = con.createStatement();
		ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
		while(eRS.next()) {
			eID = eRS.getInt("MAX(eventID)") + 1;
		}
		String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
		PreparedStatement eventStmt = con.prepareStatement(eventQuery);
		eventStmt.setInt(1, eID);
		eventStmt.setString(2, date);
		String eventAction = "Edited: " + assetTypeTF.getText() + ": Make: " + assetMakeTF.getText() + " / Model: " + assetModelTF.getText()
				+ " / Serial Number: " + assetSerialNumTF.getText();
		eventStmt.setString(3, eventAction);
		eventStmt.setString(4, user);
		eventStmt.execute();
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setContentText("Item Edited!");
		alert.showAndWait();
		callHomepage();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	TextField username;
	
	// Method for logging out
	@FXML
	private void logout() throws IOException {

		Alert alert = new Alert(AlertType.NONE, "Are you sure you want to log out?", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		if(alert.getResult().equals(ButtonType.OK)) {
			primaryStage = (Stage) quickEditButton.getScene().getWindow();

			parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Login Page");
			primaryStage.show();
			if (primaryStage.isMaximized()) {
				primaryStage.setMaximized(false);
				primaryStage.setWidth(600);
				primaryStage.setHeight(400);
			}
			
			
		}
	}
	/*
	 * The methods below allow the user to only select one check box
	 */
	@FXML
	private String laptopCBToggle() {
		if (laptopCB.isSelected() == true) {
			desktopCB.setSelected(false);
			allOneCB.setSelected(false);
			return "Laptop";
		}
		return null;
	}

	@FXML
	private String allOneCBToggle() {
		if (allOneCB.isSelected() == true) {
			desktopCB.setSelected(false);
			laptopCB.setSelected(false);
			return "All-In-One";
		}
		return null;

	}

	@FXML
	private String desktopCBToggle() {

		if (desktopCB.isSelected() == true) {
			laptopCB.setSelected(false);
			allOneCB.setSelected(false);
			return "Desktop";
		}
		return null;
	}
	// A call method to display the Home Page
	@FXML
	private void callHomepage() throws IOException {
		
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Homepage.fxml"));
		parentRoot = fxmlLoader.load();
		
		
		primaryStage = (Stage) homepageButton.getScene().getWindow();
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Home Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	/*************** Quick Edit Page ***************/
	// A call method to display the Quick Edit page
	@FXML
	private void callEditPage() throws IOException {
		
		primaryStage = (Stage) quickEditButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("QuickEdit.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Quick Edit Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	/*************** Item Creation Page ***************/
	// A call method to display the Create Item Page
	@FXML
	private void callCreatePage() throws IOException {
		primaryStage = (Stage) createItemButton.getScene().getWindow();
		
		parentRoot = FXMLLoader.load(getClass().getResource("ItemCreation.fxml"));
		
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Item Creation Page");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}
	
	
	// A call method to display the Event Logs page
	@FXML
	private void callEventLogs() throws IOException {

		
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EventLog.fxml"));
		parentRoot = fxmlLoader.load();
		EventLogController elc = fxmlLoader.<EventLogController>getController();
		elc.setEvent(eList);
		
		
		primaryStage = (Stage) eventLogButton.getScene().getWindow();
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Event Logs");
		primaryStage.show();
		if(primaryStage.isMaximized())
			primaryStage.setMaximized(true);
		
	}
	
	/*
	 * The method below changes the color of the menu bar
	 */
	@FXML
	private void mouseHover() {
		if(homepageButton.isHover()) {
			homepageButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(createItemButton.isHover()) {
			createItemButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(quickEditButton.isHover()) {
			quickEditButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(eventLogButton.isHover()) {
			eventLogButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
	}
}


