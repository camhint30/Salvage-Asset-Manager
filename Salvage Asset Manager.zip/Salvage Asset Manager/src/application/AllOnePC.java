package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

/*
 * A class of type Computer for an item creation
 */
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class AllOnePC extends Computer {

	SimpleStringProperty make, model, componentMissing, location, serviceTag, type;
	SimpleIntegerProperty capitalAsset;


	public AllOnePC() {
		
	}
	
	// A constructor that allows items to be displayed in the tableview
	public AllOnePC(String computerServiceTag, String computerComponentMissing, String computerMake, String computerModel, 
			String computerLocation, String computerType, int computerCapitalAsset) {
		super();
		this.componentMissing = new SimpleStringProperty(computerComponentMissing);
		this.make = new SimpleStringProperty(computerMake);
		this.model = new SimpleStringProperty(computerModel);
		this.location = new SimpleStringProperty(computerLocation);
		this.serviceTag = new SimpleStringProperty(computerServiceTag);
		this.capitalAsset = new SimpleIntegerProperty(computerCapitalAsset);
		this.type = new SimpleStringProperty(computerType);
	}

	public int getCapitalAsset() {
		return capitalAsset.get();
	}
	
	public void setCapitalAsset(int computerCapitalAsset) {
		capitalAsset.set(computerCapitalAsset);
	}
	public String getComputerMake() {
		return make.get();
			}

	public void setComputerMake(String computerMake) {
		make.set(computerMake);
	}

	public String getComputerModel() {
		return model.get();
	}

	public void setComputerModel(String computerModel) {
		model.set(computerModel);;
	}

	public String getComputerComponentMissing() {
		return componentMissing.get();
	}

	public void setComponentMissing(String compMissing) {
		componentMissing.set(compMissing);
	}

	public String getComputerLocation() {
		return location.get();
	}

	public void setComputerLocation(String computerLocation) {
		location.set(computerLocation);
	}

	public String getComputerType() {
		return type.get();
	}

	public void setComputerType(String computerType) {
		type.set(computerType);
	}

	public String getServiceTag() {
		return serviceTag.get();
	}

	public void setServiceTag(String cServiceTag) {
		serviceTag.set(cServiceTag);
	}
	@Override
	public String toString() {
		return "Computer [make=" + make + ", model=" + model + ", componentMissing=" + componentMissing + ", location=" + location
				+ ", capitalAsset=" + capitalAsset + ", serviceTag=" + serviceTag + ", computerType=" + type
				+ "]";
	}
	
	
	
	
}
