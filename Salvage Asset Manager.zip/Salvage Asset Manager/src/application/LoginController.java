package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class LoginController {

	@FXML
	Button loginButton, cancelBtn, submitBtn;

	@FXML
	TextField firstNameTF, lastNameTF, usernameTF, usernameText, passwordText;

	@FXML
	PasswordField passwordField, confirmPasswordField;

	static String username;

	Parent parentRoot;
	Stage primaryStage;

	/*
	 *  Method for recieving the username and password from the database and loggin the user in
	 */
	@FXML
	private void login() throws IOException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
			String loginQuery = "Select userUsername, userPassword from User where userUsername = '"
					+ usernameText.getText() + "' and userPassword = '" + passwordText.getText() + "'";

			Statement loginStmt = con.createStatement();
			ResultSet loginRS = loginStmt.executeQuery(loginQuery);

			if (loginRS.next()) {
				username = loginRS.getString("userUserName");
				FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Homepage.fxml"));
				parentRoot = fxmlLoader.load();

				primaryStage = (Stage) loginButton.getScene().getWindow();

				Scene scene = new Scene(parentRoot);

				primaryStage.setScene(scene);
				primaryStage.setTitle("Home Page");
				primaryStage.show();
				primaryStage.setMaximized(true);
			} else {
				Alert alert = new Alert(AlertType.INFORMATION);
				alert.setContentText("Username or Password incorrect");
				alert.showAndWait();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * mehtod for account creation
	 */
	@FXML
	private void registerUser() throws IOException {
		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("RegisterUser.fxml"));
		parentRoot = fxmlLoader.load();

		primaryStage = (Stage) loginButton.getScene().getWindow();

		Scene scene = new Scene(parentRoot);

		primaryStage.setScene(scene);
		primaryStage.setTitle("Register User Page");
		primaryStage.show();
	}

	/*
	 * Method for checking the database for the username and confirming it doesn't already exist
	 */
	@FXML
	private void confirmRegister() throws ClassNotFoundException, SQLException, IOException {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
			String query = "";
			PreparedStatement pStatement = null;

			String userQuery = "Select userUsername from User where userUsername ='" + usernameTF.getText() + "'";
			Statement userStmt = con.createStatement();
			ResultSet userRS = userStmt.executeQuery(userQuery);
			query = " insert into User (userUsername, userPassword, userFirstName, userLastName)"
					+ " values (?, ?, ?, ?)";
			pStatement = con.prepareStatement(query);

			if (passwordField.getText().equals(confirmPasswordField.getText()))
				pStatement.setString(2, confirmPasswordField.getText());
			else {
				passwordField.setStyle("-fx-text-box-border: red");
				confirmPasswordField.setStyle("-fx-text-box-border: red");
				Alert alert = new Alert(AlertType.ERROR);
				alert.setContentText("Passwords do not match!");
				alert.show();
			}

			if (userRS.next()) {
				if (userRS.getString("userUsername").equals(usernameTF.getText())) {
					Alert alert = new Alert(AlertType.INFORMATION);
					alert.setContentText("Username already exists...");
					alert.showAndWait();
				}
			} else {

				pStatement.setString(1, usernameTF.getText());
				pStatement.setString(3, firstNameTF.getText());
				pStatement.setString(4, lastNameTF.getText());

				pStatement.execute();
				con.close();
				Alert createAlert = new Alert(AlertType.CONFIRMATION);
				createAlert.setContentText("Account created!");
				createAlert.showAndWait();

				FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Login.fxml"));
				parentRoot = fxmlLoader.load();

				primaryStage = (Stage) submitBtn.getScene().getWindow();

				Scene scene = new Scene(parentRoot);

				primaryStage.setScene(scene);
				primaryStage.setTitle("Login Page");
				primaryStage.show();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*
	 * A method for the cancel button to return to the login screen
	 */
	@FXML
	private void callLoginPage() throws IOException {

		primaryStage = (Stage) cancelBtn.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Login Page");
		primaryStage.show();
		primaryStage.setMaximized(false);
		primaryStage.setWidth(600);
		primaryStage.setHeight(400);
	}
}
