package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */
	
import java.io.*;

import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.*;
import javafx.scene.layout.*;

public class Main extends Application { 

	@Override
	public void start(Stage primaryStage) throws IOException {
		try {
			
			FXMLLoader loader = new FXMLLoader();
			
			
			//Calls the login page when program is ran
			String fxmlDocPath = "src/application/Login.fxml";			
			FileInputStream fxmlStream = new FileInputStream(fxmlDocPath);
			
			BorderPane root = new BorderPane(loader.load(fxmlStream));
			
			Scene scene = new Scene(root);
			
			primaryStage.setScene(scene);
			
			primaryStage.setTitle("Salvage Asset Manager"); 
			
			primaryStage.show();
			
		} catch(Exception e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText(e.getMessage());
			alert.show();
			
		}
	}

	
	
	public static void main(String[] args) {
		try {
			Main.launch(Main.class);
		} catch(Exception e) {
			Alert alert = new Alert(AlertType.INFORMATION);
			alert.setContentText(e.getLocalizedMessage());
			alert.show();
		}
	}
}
