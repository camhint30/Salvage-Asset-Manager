package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.util.ArrayList;
import java.util.Date;

/*
 * A class of Event for creating events for the Event Log page
 */
public class Event {

	String user;
	String actionPerformed;
	int eventID;
	Item item;
	static int eventNumber = 0;
	String datePerformed;
	Date timePerformed;
	Event e;
	ArrayList<Event> event = new ArrayList<Event>();
	
	public Event(int eventID, String user, String datePerformed,  String actionPerformed) {
		this.eventID = eventID;
		this.user = user;
		this.datePerformed = datePerformed;
		this.actionPerformed = actionPerformed;
	}

	public int getEventID() {
		return eventID;
	}
	
	public void setEventID(int eventID) {
		this.eventID = eventID;
	}
	public String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}

	public String getActionPerformed() {
		return actionPerformed;
	}

	public void setActionPerformed(String actionPerformed) {
		this.actionPerformed = actionPerformed;
	}

	public String getDatePerformed() {
		return datePerformed;
	}

	public void setDatePerformed(String datePerformed) {
		this.datePerformed = datePerformed;
	}


	@Override
	public String toString() {

		
		return "Event # " + eventID + ": " + datePerformed + " / " + user  + " "+ actionPerformed + "\n";
	}
	
	
}
