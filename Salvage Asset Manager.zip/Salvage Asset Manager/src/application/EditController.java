package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import java.io.IOException;
import java.net.URL;
import java.sql.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.collections.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class EditController implements Initializable {

	Stage primaryStage = new Stage();
	Parent parentRoot;

	@FXML
	Button homepageButton, quickEditButton, createItemButton, eventLogButton;

	@FXML
	ObservableList<Printer> pList = FXCollections.observableArrayList(ItemCreationController.printerList);

	@FXML
	ObservableList<Computer> list = FXCollections.observableArrayList(ItemCreationController.computerList);

	@FXML
	ObservableList<Event> eList = FXCollections.observableArrayList(ItemCreationController.eventList);

	@FXML
	CheckBox desktopCB, laptopCB, allOneCB, capAssetCB;

	@FXML
	Computer computer = QuickEditController.comp;

	@FXML
	TextField serviceTagTF, makeTF, modelTF, missingComponentTF, locationTF, assetTypeTF;

	@FXML
	Label notesLbl;

	@FXML
	TextArea notesTF;
	
	DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
	String date = dateFormat.format(new Date());

	public EditController() {

	}
	
	String user = LoginController.username;

	/*
	 * The initialize is ran as the page is loaded. This reads from the database the computer assets and fills the field by the service tag entered.
	 */
	@Override
	public void initialize(URL location, ResourceBundle resource) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
			String editquery = "SELECT Item.itemMake, item.itemModel, item.itemLocation, item.itemType, item.itemCapitalAsset,"
					+ "Computer.serviceTag, computer.componentMissing FROM Item JOIN Computer WHERE Computer.computerID"
					+ " = Item.itemID AND computer.serviceTag= '" + computer.getServiceTag() + "'";
		
			String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
			
			PreparedStatement eventStmt = con.prepareStatement(eventQuery);
			
			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			int eID = 0;
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
			while (eRS.next())
				eID = eRS.getInt("MAX(eventID)");

			
			eventStmt.setInt(1, eID + 1);
			eventStmt.setString(2, date);

			
			Statement stmnt = con.createStatement();

			ResultSet editRS = stmnt.executeQuery(editquery);


			/*
			 * If statement determining if the item from the database is a Desktop, laptop or all-in-one for the checkboxes to be changed.
			 */
			while (editRS.next()) {
				if (stmnt.getResultSet().getString("Item.itemType").equalsIgnoreCase("Desktop")) {
					notesTF.setVisible(false);
					notesLbl.setVisible(false);
					serviceTagTF.setText(editRS.getString("Computer.serviceTag"));
					makeTF.setText(editRS.getString("Item.itemMake"));
					modelTF.setText(editRS.getString("Item.itemModel"));
					missingComponentTF.setText(editRS.getString("Computer.componentMissing"));
					locationTF.setText(editRS.getString("Item.itemLocation"));
					desktopCB.setSelected(true);

					if (editRS.getInt("Item.itemCapitalAsset") == 1) {
						capAssetCB.setSelected(true);
						

						String eventAction = "Edited " + desktopCB.getText() + ": Make: " + makeTF.getText() + 
								"/ Model: " + modelTF.getText() + "/ Service Tag: " + serviceTagTF.getText();
						eventStmt.setString(3, eventAction);
						eventStmt.setString(4, user);
					}
				}

				if (stmnt.getResultSet().getString("Item.itemType").equalsIgnoreCase("Laptop")) {
					notesTF.setVisible(false);
					notesLbl.setVisible(false);
					serviceTagTF.setText(editRS.getString("Computer.serviceTag"));
					makeTF.setText(editRS.getString("Item.itemMake"));
					modelTF.setText(editRS.getString("Item.itemModel"));
					missingComponentTF.setText(editRS.getString("Computer.componentMissing"));
					locationTF.setText(editRS.getString("Item.itemLocation"));
					laptopCB.setSelected(true);

					if (editRS.getInt("Item.itemCapitalAsset") == 1) {
						capAssetCB.setSelected(true);
						
					}
					String eventAction = "Edited " + desktopCB.getText() + ": Make: " + makeTF.getText() + 
							"/ Model: " + modelTF.getText() + "/ Service Tag: " + serviceTagTF.getText();
					eventStmt.setString(3, eventAction);
					eventStmt.setString(4, user);
				}

				if (stmnt.getResultSet().getString("Item.itemType").equalsIgnoreCase("All-In-One")) {
					notesTF.setVisible(false);
					notesLbl.setVisible(false);
					serviceTagTF.setText(editRS.getString("Computer.serviceTag"));
					makeTF.setText(editRS.getString("Item.itemMake"));
					modelTF.setText(editRS.getString("Item.itemModel"));
					missingComponentTF.setText(editRS.getString("Computer.componentMissing"));
					locationTF.setText(editRS.getString("Item.itemLocation"));
					allOneCB.setSelected(true);

					if (editRS.getInt("Item.itemCapitalAsset") == 1) {
						capAssetCB.setSelected(true);
					}
					String eventAction = "Edited " + desktopCB.getText() + ": Make: " + makeTF.getText() + 
							"/ Model: " + modelTF.getText() + "/ Service Tag: " + serviceTagTF.getText();
					eventStmt.setString(3, eventAction);
					eventStmt.setString(4, user);
				}
			}
			
			stmnt.close();
			editRS.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	Item item = QuickEditController.item;

	/*
	 * Method for deleting the appropriate asset in the database
	 */
	@FXML
	private void deleteItem() throws ClassNotFoundException, SQLException, IOException {

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");
		
		int id = 0;
		
		String idQuery = "SELECT * FROM Computer WHERE serviceTag = '" + computer.getServiceTag() + "'";
		Statement idStmt = con.createStatement();
		ResultSet idRS = idStmt.executeQuery(idQuery);
		
		while(idRS.next())
			id = idRS.getInt("computerID");
		
		String compDelete = "DELETE FROM Computer WHERE computerID = " + id;
		String itemDelete = "DELETE FROM Item WHERE itemID = " + id;
		
		PreparedStatement compStmt = con.prepareStatement(compDelete);
		PreparedStatement itemStmt = con.prepareStatement(itemDelete);
		
		Alert alert = new Alert(AlertType.CONFIRMATION);
		alert.setContentText("Are you sure you want to delete this item?");
		Optional<ButtonType> result = alert.showAndWait();
		ButtonType button = result.orElse(ButtonType.CANCEL);

		if (button == ButtonType.OK) {
			compStmt.execute(compDelete);
			itemStmt.execute(itemDelete);
			int eID = 0;
			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
			while(eRS.next()) {
				eID = eRS.getInt("MAX(eventID)") + 1;
			}
			
			String computerType = "";
			if(desktopCB.isSelected()) {
				computerType = desktopCB.getText();
			}
			if(laptopCB.isSelected()) {
				computerType = laptopCB.getText();
			}
			if(allOneCB.isSelected()) {
				computerType = allOneCB.getText();
			}
			String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
			PreparedStatement eventStmt = con.prepareStatement(eventQuery);
			eventStmt.setInt(1, eID);
			eventStmt.setString(2, date);
			String eventAction = "Deleted: " + computerType + ": Make: " + makeTF.getText() + " / Model: " + modelTF.getText()
					+ " / Service Tag: " + serviceTagTF.getText();
			eventStmt.setString(3, eventAction);
			eventStmt.setString(4, user);
			eventStmt.execute();
			callHomepage();
		}
		

	}
	
	
	/*
	 * 
	 * Method for submitting the update to the database
	 */

	@FXML
	private void submitEdit() throws ClassNotFoundException, SQLException {

		try {
		String computerType = null;

		if (desktopCB.isSelected())
			computerType = desktopCB.getText();

		if (laptopCB.isSelected())
			computerType = laptopCB.getText();

		if (allOneCB.isSelected())
			computerType = allOneCB.getText();
		
		int capAsset = 0;
		
		if(capAssetCB.isSelected())
			capAsset = 1;

		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/db", "root", "password");

		String query = "UPDATE Item JOIN Computer SET " + "item.itemMake='" + makeTF.getText() + "', "
				+ "item.itemModel='" + modelTF.getText() + "', " + "item.itemLocation='" + locationTF.getText() + "', "
				+ "computer.componentMissing='" + missingComponentTF.getText() + "', " + "item.itemType='"
				+ computerType + "', computer.serviceTag='" + computer.getServiceTag() + "', item.itemCapitalAsset ='" + capAsset +
				"' WHERE "
				+ "computer.serviceTag= '" + computer.getServiceTag() + "' AND computer.computerID = item.itemID";

		Statement stmt = con.prepareStatement(query);
		
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setContentText("Item Editted.");
		Optional<ButtonType> result = alert.showAndWait();
		ButtonType button = result.orElse(ButtonType.CANCEL);

		if (button == ButtonType.OK) {
			stmt.executeUpdate(query);
			int eID = 0;
			String eIDQuery = "SELECT MAX(eventID) FROM Events";
			Statement eIDStmt = con.createStatement();
			ResultSet eRS = eIDStmt.executeQuery(eIDQuery);
			while(eRS.next()) {
				eID = eRS.getInt("MAX(eventID)") + 1;
			}
			
			String eventQuery = "INSERT INTO Events (eventID, eventDate, eventAction, eventUsername) VALUES (?,?,?,?)";
			PreparedStatement eventStmt = con.prepareStatement(eventQuery);
			eventStmt.setInt(1, eID);
			eventStmt.setString(2, date);
			String eventAction = "Edited: " + computerType + ": Make: " + makeTF.getText() + " / Model: " + modelTF.getText()
					+ " / Service Tag: " + serviceTagTF.getText();
			eventStmt.setString(3, eventAction);
			eventStmt.setString(4, user);
			eventStmt.execute();
			callHomepage();
		} 
		} catch(Exception e) {
			e.printStackTrace();
		}

	}

	/*
	 * 
	 * The 3 methods below change the checkboxes and not allowing the user to select more than one.
	 */
	@FXML
	private String laptopCBToggle() {
		if (laptopCB.isSelected() == true) {
			desktopCB.setSelected(false);
			allOneCB.setSelected(false);
			return "Laptop";
		}
		return null;
	}

	@FXML
	private String allOneCBToggle() {
		if (allOneCB.isSelected() == true) {
			desktopCB.setSelected(false);
			laptopCB.setSelected(false);
			return "All-In-One";
		}
		return null;

	}

	@FXML
	private String desktopCBToggle() {

		if (desktopCB.isSelected() == true) {
			laptopCB.setSelected(false);
			allOneCB.setSelected(false);
			return "Desktop";
		}
		return null;
	}

	// A call method to display the Home Page
	@FXML
	private void callHomepage() throws IOException {

		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("Homepage.fxml"));
		parentRoot = fxmlLoader.load();

		primaryStage = (Stage) homepageButton.getScene().getWindow();

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Home Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*************** Quick Edit Page ***************/
	// A call method to display the Quick Edit page
	@FXML
	private void callEditPage() throws IOException {

		primaryStage = (Stage) quickEditButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("QuickEdit.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Quick Edit Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	/*************** Item Creation Page ***************/
	// A call method to display the Create Item Page
	@FXML
	private void callCreatePage() throws IOException {
		primaryStage = (Stage) createItemButton.getScene().getWindow();

		parentRoot = FXMLLoader.load(getClass().getResource("ItemCreation.fxml"));

		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Item Creation Page");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);
	}

	// A call method to display the Event Logs page
	@FXML
	private void callEventLogs() throws IOException {


		FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("EventLog.fxml"));
		parentRoot = fxmlLoader.load();
		EventLogController elc = fxmlLoader.<EventLogController>getController();
		elc.setEvent(eList);

		primaryStage = (Stage) eventLogButton.getScene().getWindow();
		primaryStage.getScene().setRoot(parentRoot);
		primaryStage.setTitle("Event Logs");
		primaryStage.show();
		if (primaryStage.isMaximized())
			primaryStage.setMaximized(true);

	}
	
	//A simple logout method
	
	@FXML
	private void logout() throws IOException {

		Alert alert = new Alert(AlertType.NONE, "Are you sure you want to log out?", ButtonType.OK, ButtonType.CANCEL);
		alert.showAndWait();
		if(alert.getResult().equals(ButtonType.OK)) {
			primaryStage = (Stage) quickEditButton.getScene().getWindow();

			parentRoot = FXMLLoader.load(getClass().getResource("Login.fxml"));

			primaryStage.getScene().setRoot(parentRoot);
			primaryStage.setTitle("Login Page");
			primaryStage.show();
			if (primaryStage.isMaximized()) {
				primaryStage.setMaximized(false);
				primaryStage.setWidth(600);
				primaryStage.setHeight(400);
			}
			
		}
	}
	
	/*
	 * Method to change the color of the menubar items
	 */
	
	@FXML
	private void mouseHover() {
		if(homepageButton.isHover()) {
			homepageButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(createItemButton.isHover()) {
			createItemButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(quickEditButton.isHover()) {
			quickEditButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			eventLogButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
		else if(eventLogButton.isHover()) {
			eventLogButton.setStyle("-fx-background-color: #0099FF; -fx-background-radius: 0; -fx-text-fill: #FFFFFF");
			homepageButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			quickEditButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
			createItemButton.setStyle("-fx-background-color: #FFFFFF; -fx-background-radius: 0; -fx-text-fill: #000000");
		}
	}
}
