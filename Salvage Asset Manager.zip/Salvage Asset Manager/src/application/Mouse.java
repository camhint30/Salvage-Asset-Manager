
package application;

/*
 * 
 * Author Cameren Hinton
 * Author Sameer Karali
 * Author Justin Lambrecht
 * Author Aaron Manchester
 * 
 */

import javafx.beans.property.*;

// A class for creating an Item of type Mouse
public class Mouse extends Item {
	
	SimpleStringProperty mouseMake;
	SimpleIntegerProperty mouseQuantity;
	
	public Mouse() {
		
	}
	
	public Mouse(String make, int quantity) {
		super();
		this.mouseMake = new SimpleStringProperty(make);
		this.mouseQuantity = new SimpleIntegerProperty(quantity);
	}

	public void setMouseQuantity(int quantity) {
		mouseQuantity.set(quantity);
	}
	
	public int getMouseQuantity() {
		return mouseQuantity.get();
	}
	public void setMouseMake(String make) {
		this.mouseMake.set(make);
	}
	
	public String getMouseMake() {
		return mouseMake.get();
	}
	
	@Override
	public String toString() {
		return "Mouse/" + mouseMake + "quantity: " + mouseQuantity;
	}

}